| Métrica | Valor |
|---|---|
| experimento | senales_elementales |
| tipo | rampa |
| amplitud | 1.0 |
| t0 | 0.0 |
| fs | 500.0 |
| duracion | 3.0 |
| sigma | -1.0 |
| frecuencia | 2.0 |
| ancho | 1.0 |
| n_muestras | 1500 |
| energia | 2.6626679999999996 |
| potencia_media | 0.8875559999999999 |
| valor_max | 1.9980000000000002 |
| valor_min | 0.0 |
| media | 0.666 |
| rms | 0.94210190531598 |
| Tipo de señal | rampa |
| Amplitud A | 1.0 |
| Desplazamiento t₀ [s] | 0.0 |
| Energía E = ∫x²dt | 2.662668 |
| Potencia media P | 0.887556 |
| Valor máximo | 1.998 |
| N° de muestras | 1500 |
