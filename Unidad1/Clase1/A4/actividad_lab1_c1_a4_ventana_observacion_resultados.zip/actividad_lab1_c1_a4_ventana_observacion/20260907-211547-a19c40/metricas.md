| Métrica | Valor |
|---|---|
| experimento | ventana_observacion |
| tipo_senal | senoidal_potencia |
| fs | 2000.0 |
| tau | 0.5 |
| amplitud | 1.0 |
| n_ventanas | 24 |
| energia_final | 4.0 |
| potencia_final | 0.5 |
| delta_E_relativo_final | 0.04269376965818106 |
| energia_convergio | False |
| T_obs_suficiente_s | 0.0 |
| T_obs_suficiente_en_taus | 0.0 |
| potencia_media_teorica_sinusoide | 0.5 |
| clasificacion | señal de potencia |
| Señal | senoidal_potencia |
| Ventanas barridas | 24 |
| E medida en T_max | 4.0 |
| P medida en T_max | 0.5 |
| ¿E convergió (|ΔE|/E ≤ tol)? | False |
| T_obs suficiente [s] | 0.0 |
| T_obs suficiente / τ | 0.0 |
| P teórica de una sinusoide A²/2 | 0.5 |
| Clasificación medida | señal de potencia |
