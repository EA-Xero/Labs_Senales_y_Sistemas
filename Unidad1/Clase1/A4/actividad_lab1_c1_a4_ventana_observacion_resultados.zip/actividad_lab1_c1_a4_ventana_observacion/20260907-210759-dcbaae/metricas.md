| Métrica | Valor |
|---|---|
| experimento | ventana_observacion |
| tipo_senal | exponencial_energia |
| fs | 2000.0 |
| tau | 0.5 |
| amplitud | 1.0 |
| n_ventanas | 24 |
| energia_final | 0.2502500833333246 |
| potencia_final | 0.031281260416665575 |
| delta_E_relativo_final | 3.748803769862041e-14 |
| energia_convergio | True |
| T_obs_suficiente_s | 1.432608695652174 |
| T_obs_suficiente_en_taus | 2.865217391304348 |
| potencia_media_teorica_sinusoide | 0.5 |
| clasificacion | ni de energía ni de potencia |
| Señal | exponencial_energia |
| Ventanas barridas | 24 |
| E medida en T_max | 0.25025 |
| P medida en T_max | 0.031281 |
| ¿E convergió (|ΔE|/E ≤ tol)? | True |
| T_obs suficiente [s] | 1.4326 |
| T_obs suficiente / τ | 2.865 |
| P teórica de una sinusoide A²/2 | 0.5 |
| Clasificación medida | ni de energía ni de potencia |
