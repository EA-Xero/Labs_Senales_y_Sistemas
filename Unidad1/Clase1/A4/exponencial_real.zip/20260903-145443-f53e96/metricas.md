| Métrica | Valor |
|---|---|
| experimento | senales_elementales |
| tipo | exponencial_real |
| amplitud | 1.0 |
| t0 | 0.0 |
| fs | 500.0 |
| duracion | 5.0 |
| sigma | -1.0 |
| frecuencia | 2.0 |
| ancho | 1.0 |
| n_muestras | 2500 |
| energia | 3.7017539646001207 |
| potencia_media | 0.7403507929200241 |
| valor_max | 2.718281828459045 |
| valor_min | 0.01835230682222249 |
| media | 0.5405334111497103 |
| rms | 0.8604363967894572 |
| Tipo de señal | exponencial_real |
| Amplitud A | 1.0 |
| Desplazamiento t₀ [s] | 0.0 |
| Energía E = ∫x²dt | 3.701754 |
| Potencia media P | 0.740351 |
| Valor máximo | 2.718282 |
| N° de muestras | 2500 |
