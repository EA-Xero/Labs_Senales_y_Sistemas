# Actividad guiada: A4 · La ventana de observación cambia la clasificación
Laboratorio 1 · Unidad 1 · Clase 1 (Clasificación de señales)
#### A4 · La ventana de observación cambia la clasificación  ·  20 min
*Experimento:* `ventana_observacion`

**Objetivo.** Barrer la duración observada y ver cómo E converge y P tiende a cero en una señal de energía, mientras P se estabiliza en una periódica: el experimento de la figura 1.2 de la tutoría.

**Procedimiento**

1. Lanza la corrida principal (exponencial de energía) y observa E(T) y P(T) construyéndose ventana a ventana.
2. Localiza el T_obs suficiente que el simulador reporta y exprésalo en múltiplos de τ.
3. Repite con la variante periódica: P se mantiene y E crece linealmente.
4. Concluye qué ventana mínima usará el grupo en el resto del laboratorio.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Señal de energía: |ΔE|/E ≤ tolerancia al crecer T_obs | Gráfico E vs T_obs (PNG/SVG) |
| Señal periódica: P estable ≈ A²/2 y E creciente | Gráfico P vs T_obs + tabla CSV |

**Preguntas de análisis (van al informe)**

- ¿Cuántos τ necesita observar para que E deje de cambiar?
- ¿Qué error de clasificación cometería con T_obs = τ/2?
