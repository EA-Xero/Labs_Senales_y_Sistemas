| Métrica | Valor |
|---|---|
| experimento | energia_potencia |
| senal | pulso_rectangular |
| amplitud | 1.0 |
| frecuencia | 2.0 |
| tau | 0.5 |
| desfase | 0.0 |
| fs | 500.0 |
| duracion | 4.0 |
| semilla | 7 |
| n_muestras | 2000 |
| energia | 1.002 |
| potencia_media | 0.2505 |
| valor_rms | 0.500499750249688 |
| periodo_estimado_s | 2.502 |
| frecuencia_estimada_hz | 0.39968025579536376 |
| correlacion_periodo | 0.12516644429619742 |
| es_periodica | False |
| energia_par | 1.0010000000000001 |
| energia_impar | 0.001 |
| fraccion_par | 0.9990019960079841 |
| fraccion_impar | 0.000998003992015968 |
| simetria | par |
| clasificacion | de energía |
| aporte_energia_cola | 0.0 |
| Señal | pulso_rectangular |
| Energía E [u²·s] | 1.002 |
| Potencia media P [u²] | 0.2505 |
| Valor RMS | 0.5005 |
| Periodo estimado [s] | 2.502 |
| ¿Periódica? | no |
| Clasificación | de energía |
| Simetría | par |
| Fracción de energía par | 0.999 |
| Fracción de energía impar | 0.001 |
