| Métrica | Valor |
|---|---|
| experimento | energia_potencia |
| senal | senoidal |
| amplitud | 1.0 |
| frecuencia | 2.0 |
| tau | 0.5 |
| desfase | 0.0 |
| fs | 500.0 |
| duracion | 4.0 |
| semilla | 7 |
| n_muestras | 2000 |
| energia | 1.9999999999999998 |
| potencia_media | 0.49999999999999994 |
| valor_rms | 0.7071067811865475 |
| periodo_estimado_s | 0.5 |
| frecuencia_estimada_hz | 2.0 |
| correlacion_periodo | 0.8749999999999999 |
| es_periodica | True |
| energia_par | 0.0003158107167000169 |
| energia_impar | 1.9996841892833 |
| fraccion_par | 0.00015790535835000848 |
| fraccion_impar | 0.9998420946416501 |
| simetria | impar |
| clasificacion | de potencia |
| aporte_energia_cola | 0.19071440361539183 |
| Señal | senoidal |
| Energía E [u²·s] | 2.0 |
| Potencia media P [u²] | 0.5 |
| Valor RMS | 0.707107 |
| Periodo estimado [s] | 0.5 |
| ¿Periódica? | sí |
| Clasificación | de potencia |
| Simetría | impar |
| Fracción de energía par | 0.0002 |
| Fracción de energía impar | 0.9998 |
