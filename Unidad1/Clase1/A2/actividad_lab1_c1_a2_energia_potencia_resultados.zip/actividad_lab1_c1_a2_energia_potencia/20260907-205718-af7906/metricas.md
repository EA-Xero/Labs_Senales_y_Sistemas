| Métrica | Valor |
|---|---|
| experimento | energia_potencia |
| senal | exponencial_decreciente |
| amplitud | 1.0 |
| frecuencia | 2.0 |
| tau | 0.5 |
| desfase | 0.0 |
| fs | 500.0 |
| duracion | 4.0 |
| semilla | 7 |
| n_muestras | 2000 |
| energia | 0.49983493445530486 |
| potencia_media | 0.12495873361382621 |
| valor_rms | 0.3534950262929115 |
| periodo_estimado_s | 2.99 |
| frecuencia_estimada_hz | 0.33444816053511706 |
| correlacion_periodo | 0.131312798798494 |
| es_periodica | False |
| energia_par | 0.499832935128896 |
| energia_impar | 1.9993264089764093e-06 |
| fraccion_par | 0.9999960000266667 |
| fraccion_impar | 3.999973333506941e-06 |
| simetria | par |
| clasificacion | de energía |
| aporte_energia_cola | 0.003964260556459793 |
| Señal | exponencial_decreciente |
| Energía E [u²·s] | 0.499835 |
| Potencia media P [u²] | 0.124959 |
| Valor RMS | 0.353495 |
| Periodo estimado [s] | 2.99 |
| ¿Periódica? | no |
| Clasificación | de energía |
| Simetría | par |
| Fracción de energía par | 1.0 |
| Fracción de energía impar | 0.0 |
