| Métrica | Valor |
|---|---|
| experimento | senales_elementales |
| tipo | rectangular |
| amplitud | 1.0 |
| t0 | 0.0 |
| fs | 500.0 |
| duracion | 3.0 |
| sigma | -1.0 |
| frecuencia | 2.0 |
| ancho | 1.0 |
| n_muestras | 1500 |
| energia | 1.002 |
| potencia_media | 0.334 |
| valor_max | 1.0 |
| valor_min | 0.0 |
| media | 0.334 |
| rms | 0.5779273310719956 |
| Tipo de señal | rectangular |
| Amplitud A | 1.0 |
| Desplazamiento t₀ [s] | 0.0 |
| Energía E = ∫x²dt | 1.002 |
| Potencia media P | 0.334 |
| Valor máximo | 1.0 |
| N° de muestras | 1500 |
