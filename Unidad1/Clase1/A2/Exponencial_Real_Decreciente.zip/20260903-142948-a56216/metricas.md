| Métrica | Valor |
|---|---|
| experimento | senales_elementales |
| tipo | exponencial_real |
| amplitud | 1.0 |
| t0 | 0.0 |
| fs | 500.0 |
| duracion | 3.0 |
| sigma | -1.0 |
| frecuencia | 2.0 |
| ancho | 1.0 |
| n_muestras | 1500 |
| energia | 3.692745884306663 |
| potencia_media | 1.2309152947688877 |
| valor_max | 2.718281828459045 |
| valor_min | 0.13560622465418967 |
| media | 0.861843450916593 |
| rms | 1.1094662206524757 |
| Tipo de señal | exponencial_real |
| Amplitud A | 1.0 |
| Desplazamiento t₀ [s] | 0.0 |
| Energía E = ∫x²dt | 3.692746 |
| Potencia media P | 1.230915 |
| Valor máximo | 2.718282 |
| N° de muestras | 1500 |
