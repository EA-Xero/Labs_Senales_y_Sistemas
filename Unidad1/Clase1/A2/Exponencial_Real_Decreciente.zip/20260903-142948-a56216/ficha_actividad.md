# Actividad guiada: A2 · Energía frente a potencia: clasificar con números
Laboratorio 1 · Unidad 1 · Clase 1 (Clasificación de señales)
#### A2 · Energía frente a potencia: clasificar con números  ·  20 min
*Experimento:* `energia_potencia`

**Objetivo.** Clasificar tres señales (periódica, con decaimiento y pulso) como señal de energía o de potencia usando E y P medidas, no la forma.

**Procedimiento**

1. Lanza la actividad: corre una senoidal, una exponencial decreciente y un pulso rectangular con la misma ventana de observación.
2. Anota E y P de cada corrida y compara P de la senoidal con A²/2.
3. Clasifica cada señal y justifica con el par (E, P), no con la figura.
4. Exporta el **bundle ZIP de la actividad**: trae las tres corridas juntas y el `resumen_corridas.csv` para la tabla del informe.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Senoidal: P ≈ A²/2 y E crece con la ventana | resumen_corridas.csv del bundle de la actividad |
| Exponencial y pulso: E finita y P → 0 al alargar la ventana | Tabla CSV de energía y potencia |

**Preguntas de análisis (van al informe)**

- ¿Por qué una señal periódica no puede ser señal de energía?
- ¿Qué señal de las tres se acerca más a «ni de energía ni de potencia» y por qué?
