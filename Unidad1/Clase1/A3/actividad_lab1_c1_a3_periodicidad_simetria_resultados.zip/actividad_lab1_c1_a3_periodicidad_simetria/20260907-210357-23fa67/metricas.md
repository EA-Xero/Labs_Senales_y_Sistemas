| Métrica | Valor |
|---|---|
| experimento | periodicidad_simetria |
| tipo_senal | suma_senoidales |
| fs | 2000.0 |
| duracion_observada | 2.0 |
| n_muestras | 4001 |
| energia | 1.49 |
| potencia_media | 0.7448137965508623 |
| energia_par | 0.0 |
| energia_impar | 1.49 |
| suma_Ep_Ei | 1.49 |
| residuo_relativo_energia | 0.0 |
| identidad_E_igual_Ep_mas_Ei | True |
| periodo_estimado_s | 0.4 |
| periodo_teorico_s | 0.6000000000000001 |
| error_relativo_periodo | 0.33333333333333337 |
| correlacion_en_periodo | 0.8 |
| periodica_medida | False |
| clasificacion | ni de energía ni de potencia / revisar ventana |
| simetria | impar |
| razon_f_fs | 0.0025 |
| periodo_discreto_N | 400 |
| periodica_en_tiempo_discreto | True |
| Señal | suma_senoidales |
| Periodo estimado por autocorrelación [s] | 0.4 |
| Periodo teórico [s] | 0.6 |
| Error relativo del periodo | 0.333333 |
| ¿Periódica (medida)? | False |
| ¿Periódica en tiempo discreto (f/fs racional)? | True |
| N discreto (denominador de f/fs) | 400 |
| Energía E | 1.49 |
| Ep (parte par) | 0.0 |
| Ei (parte impar) | 1.49 |
| Ep + Ei | 1.49 |
| Residuo relativo |E−(Ep+Ei)|/E | 0.0 |
| Simetría detectada | impar |
| Clasificación energía/potencia | ni de energía ni de potencia / revisar ventana |
