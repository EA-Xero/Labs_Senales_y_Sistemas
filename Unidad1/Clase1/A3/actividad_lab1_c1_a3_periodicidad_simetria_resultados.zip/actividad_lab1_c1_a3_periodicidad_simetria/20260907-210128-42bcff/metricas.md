| Métrica | Valor |
|---|---|
| experimento | periodicidad_simetria |
| tipo_senal | senoidal |
| fs | 2000.0 |
| duracion_observada | 2.0 |
| n_muestras | 4001 |
| energia | 1.0 |
| potencia_media | 0.49987503124218946 |
| energia_par | 0.0 |
| energia_impar | 1.0 |
| suma_Ep_Ei | 1.0 |
| residuo_relativo_energia | 0.0 |
| identidad_E_igual_Ep_mas_Ei | True |
| periodo_estimado_s | 0.2 |
| periodo_teorico_s | 0.2 |
| error_relativo_periodo | 0.0 |
| correlacion_en_periodo | 0.9 |
| periodica_medida | True |
| clasificacion | señal de potencia (periódica) |
| simetria | impar |
| razon_f_fs | 0.0025 |
| periodo_discreto_N | 400 |
| periodica_en_tiempo_discreto | True |
| Señal | senoidal |
| Periodo estimado por autocorrelación [s] | 0.2 |
| Periodo teórico [s] | 0.2 |
| Error relativo del periodo | 0.0 |
| ¿Periódica (medida)? | True |
| ¿Periódica en tiempo discreto (f/fs racional)? | True |
| N discreto (denominador de f/fs) | 400 |
| Energía E | 1.0 |
| Ep (parte par) | 0.0 |
| Ei (parte impar) | 1.0 |
| Ep + Ei | 1.0 |
| Residuo relativo |E−(Ep+Ei)|/E | 0.0 |
| Simetría detectada | impar |
| Clasificación energía/potencia | señal de potencia (periódica) |
