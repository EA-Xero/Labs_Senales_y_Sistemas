| Métrica | Valor |
|---|---|
| experimento | senales_elementales |
| tipo | senoidal |
| amplitud | 1.0 |
| t0 | 0.0 |
| fs | 500.0 |
| duracion | 3.0 |
| sigma | -1.0 |
| frecuencia | 2.0 |
| ancho | 1.0 |
| n_muestras | 1500 |
| energia | 1.5000000000000002 |
| potencia_media | 0.5000000000000001 |
| valor_max | 0.9999210442038161 |
| valor_min | -0.9999210442038161 |
| media | 0.0 |
| rms | 0.7071067811865476 |
| Tipo de señal | senoidal |
| Amplitud A | 1.0 |
| Desplazamiento t₀ [s] | 0.0 |
| Energía E = ∫x²dt | 1.5 |
| Potencia media P | 0.5 |
| Valor máximo | 0.999921 |
| N° de muestras | 1500 |
