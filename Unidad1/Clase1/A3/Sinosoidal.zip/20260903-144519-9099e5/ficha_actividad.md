# Actividad guiada: A3 · Periodo por autocorrelación y simetría par/impar
Laboratorio 1 · Unidad 1 · Clase 1 (Clasificación de señales)
#### A3 · Periodo por autocorrelación y simetría par/impar  ·  20 min
*Experimento:* `periodicidad_simetria`

**Objetivo.** Medir el periodo con autocorrelación, comprobar la condición de periodicidad discreta (f/fs racional) y verificar E = Ep + Ei.

**Procedimiento**

1. Lanza la corrida principal (senoidal): compara el T₀ estimado con 1/f.
2. Observa la variante «suma_senoidales»: el periodo medido debe coincidir con el mínimo común múltiplo de los dos periodos.
3. Observa la variante discreta no periódica: la razón f/fs deja de ser racional y la secuencia nunca se repite exactamente.
4. En *Resultados*, verifica el residuo |E−(Ep+Ei)|/E y describe la simetría detectada.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Error relativo del periodo estimado ≤ tolerancia | Tabla CSV + figura de autocorrelación |
| E = Ep + Ei con residuo ≤ tolerancia | Tabla CSV del balance de energía |
| Periodicidad discreta sólo si f/fs es racional | Campos razon_f_fs y periodo_discreto_N |

**Preguntas de análisis (van al informe)**

- ¿Por qué la descomposición par/impar no genera términos cruzados de energía?
- ¿Qué N discreto obtuvo y qué significa para el largo mínimo de la ventana?

**Errores frecuentes**

- Tomar el máximo trivial de la autocorrelación en τ=0 como periodo.
- Declarar periódica una sinusoide discreta sin comprobar que f/fs es racional.
