| Métrica | Valor |
|---|---|
| experimento | senales_elementales |
| tipo | escalon |
| amplitud | 1.0 |
| t0 | 0.0 |
| fs | 500.0 |
| duracion | 3.0 |
| sigma | -1.0 |
| frecuencia | 2.0 |
| ancho | 1.0 |
| n_muestras | 1500 |
| energia | 2.0 |
| potencia_media | 0.6666666666666666 |
| valor_max | 1.0 |
| valor_min | 0.0 |
| media | 0.6666666666666666 |
| rms | 0.816496580927726 |
| Tipo de señal | escalon |
| Amplitud A | 1.0 |
| Desplazamiento t₀ [s] | 0.0 |
| Energía E = ∫x²dt | 2.0 |
| Potencia media P | 0.666667 |
| Valor máximo | 1.0 |
| N° de muestras | 1500 |
