# Actividad guiada: A1 · Puesta en marcha: señales elementales
Laboratorio 1 · Unidad 1 · Clase 1 (Clasificación de señales)
#### A1 · Puesta en marcha: señales elementales  ·  15 min
*Experimento:* `senales_elementales`

**Objetivo.** Comprobar que el simulador calcula de verdad: generar el escalón, el impulso discreto y la rampa, y leer sus métricas en Resultados.

**Procedimiento**

1. Lanza la actividad y observa en *Vista en vivo* cómo la señal se dibuja muestra a muestra (la energía acumulada crece con cada bloque).
2. En *Resultados*, revisa la tabla de valores de interés: energía, potencia media, RMS, máximo y número de muestras.
3. Descarga el **bundle ZIP de la corrida**: será la primera evidencia del informe y contiene los gráficos en PNG y SVG.
4. Repite con las variantes (impulso y rampa) y compara las tres tablas.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| El escalón tiene potencia media no nula y energía creciente con Tobs | Tabla CSV de valores de interés |
| El impulso discreto vale A en una única muestra y 0 en el resto | Figura PNG/SVG de la señal |

**Preguntas de análisis (van al informe)**

- ¿Qué valores de fs y de duración usó, y por qué esos y no otros?
- ¿La rampa es señal de energía o de potencia en la ventana observada?

**Errores frecuentes**

- Reportar una figura sin indicar fs ni la duración observada.
- Confundir el impulso discreto δ[n] con una aproximación continua de δ(t).
