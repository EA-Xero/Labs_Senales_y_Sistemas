| Métrica | Valor |
|---|---|
| experimento | senales_elementales |
| tipo | rampa |
| amplitud | 1.0 |
| t0 | 0.0 |
| fs | 500.0 |
| duracion | 10.0 |
| sigma | -1.0 |
| frecuencia | 2.0 |
| ancho | 1.0 |
| n_muestras | 5000 |
| energia | 242.91900599999997 |
| potencia_media | 24.291900599999998 |
| valor_max | 8.998 |
| valor_min | 0.0 |
| media | 4.049099999999999 |
| rms | 4.928681426101711 |
| Tipo de señal | rampa |
| Amplitud A | 1.0 |
| Desplazamiento t₀ [s] | 0.0 |
| Energía E = ∫x²dt | 242.919006 |
| Potencia media P | 24.291901 |
| Valor máximo | 8.998 |
| N° de muestras | 5000 |
