# Actividad guiada: A4 · Transformación combinada y predicción previa
Laboratorio 1 · Unidad 1 · Clase 2 (Transformación de la variable independiente)
#### A4 · Transformación combinada y predicción previa  ·  10 min
*Experimento:* `barrido_transformaciones`

**Objetivo.** Predecir soporte y máximo de una transformación combinada y contrastar con la medición.

**Procedimiento**

1. Antes de lanzar, calcula a mano el máximo esperado (τ+t₀)/a de cada paso.
2. Lanza el barrido combinado y compara medición contra predicción.
3. Documenta la diferencia máxima en muestras (no en segundos).

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Error del máximo ≤ pocas muestras (1/fs) | Gráfico corrimiento efectivo + tabla CSV |

**Preguntas de análisis (van al informe)**

- ¿La discrepancia restante se explica por 1/fs? Justifique.
