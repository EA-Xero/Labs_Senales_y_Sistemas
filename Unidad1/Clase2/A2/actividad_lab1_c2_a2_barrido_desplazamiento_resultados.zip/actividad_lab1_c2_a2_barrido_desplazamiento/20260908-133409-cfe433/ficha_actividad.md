# Actividad guiada: A2 · Barrido de desplazamiento con a = 1
Laboratorio 1 · Unidad 1 · Clase 2 (Transformación de la variable independiente)
#### A2 · Barrido de desplazamiento con a = 1  ·  10 min
*Experimento:* `barrido_transformaciones`

**Objetivo.** Comprobar que desplazar no altera energía, potencia ni periodo: la energía medida debe ser la misma en los cinco valores de t₀.

**Procedimiento**

1. Lanza el barrido de desplazamiento (a fijo en 1).
2. Verifica en la tabla que el error relativo de E se mantiene bajo la tolerancia en todos los pasos.
3. Comprueba que el máximo se mueve exactamente t₀ segundos.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| |Ey − Ex|/Ex ≤ tolerancia para todo t₀ | Tabla CSV de energías |
| Máximo medido = τ + t₀ (a = 1) | Gráfico de corrimiento efectivo |

**Preguntas de análisis (van al informe)**

- ¿Cambió el periodo al desplazar? ¿Por qué?
