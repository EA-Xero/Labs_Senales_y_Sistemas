| Métrica | Valor |
|---|---|
| experimento | barrido_transformaciones |
| senal_base | pulso_asimetrico |
| modo_barrido | desplazamiento |
| fs | 4000.0 |
| n_pasos | 9 |
| energia_base_Ex | 0.33345834375000005 |
| potencia_base_Px | 0.027788195312500003 |
| tau_maximo_base_s | 1.0 |
| error_max_energia_rel | 0.0 |
| error_max_pico_s | 0.0 |
| error_max_potencia_rel | 0.0 |
| verificacion_Ey_igual_Ex_sobre_abs_a | True |
| verificacion_corrimiento_efectivo | True |
| verificacion_potencia_invariante | True |
| verificacion_energia_invariante_al_desplazamiento | True |
| Señal base | pulso_asimetrico |
| Barrido | desplazamiento |
| E_x (base) | 0.333458 |
| P_x (base) | 0.027788 |
| Máximo de la base τ [s] | 1.0 |
| Error máximo en E_y vs E_x/|a| | 0.0 |
| Error máximo en la posición del máximo [s] | 0.0 |
| Error máximo en P_y vs P_x | 0.0 |
| ✔ Ey = Ex/|a| | True |
| ✔ máximo en (τ+t₀)/a | True |
| ✔ potencia invariante | True |
