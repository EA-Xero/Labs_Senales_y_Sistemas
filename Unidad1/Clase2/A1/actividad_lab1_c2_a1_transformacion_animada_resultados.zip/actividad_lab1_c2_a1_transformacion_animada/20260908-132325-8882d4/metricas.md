| Métrica | Valor |
|---|---|
| experimento | transformaciones_variable |
| base | doble_pulso |
| a | -1.0 |
| a_efectivo | -1.0 |
| t0 | 1.0 |
| reflexion | False |
| fs | 400.0 |
| n_muestras | 3200 |
| energia_original | 1.0858343750000001 |
| energia_transformada | 1.0858343750000001 |
| energia_esperada | 1.0858343750000001 |
| error_relativo_energia | 0.0 |
| desplazamiento_efectivo_s | -1.0 |
| factor_compresion | 1.0 |
| hay_reflexion | True |
| max_original | 1.0 |
| max_transformada | 1.0 |
| Señal base | doble_pulso |
| Escala a (efectiva) | -1.0 |
| Desplazamiento t₀ | 1.0 |
| Desplazamiento efectivo t₀/a [s] | -1.0 |
| ¿Hay reflexión? | sí |
| Energía x(t) | 1.085834 |
| Energía y(t) | 1.085834 |
| E_x/|a| (teórica) | 1.085834 |
| Error relativo de energía | 0.0 |
