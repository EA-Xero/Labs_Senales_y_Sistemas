| Métrica | Valor |
|---|---|
| experimento | senales_elementales |
| tipo | triangular |
| amplitud | 1.0 |
| t0 | 0.0 |
| fs | 500.0 |
| duracion | 3.0 |
| sigma | -1.0 |
| frecuencia | 2.0 |
| ancho | 2.0 |
| n_muestras | 1500 |
| energia | 0.6666679999999999 |
| potencia_media | 0.22222266666666662 |
| valor_max | 1.0 |
| valor_min | 0.0 |
| media | 0.3333333333333333 |
| rms | 0.47140499219531673 |
| Tipo de señal | triangular |
| Amplitud A | 1.0 |
| Desplazamiento t₀ [s] | 0.0 |
| Energía E = ∫x²dt | 0.666668 |
| Potencia media P | 0.222223 |
| Valor máximo | 1.0 |
| N° de muestras | 1500 |
