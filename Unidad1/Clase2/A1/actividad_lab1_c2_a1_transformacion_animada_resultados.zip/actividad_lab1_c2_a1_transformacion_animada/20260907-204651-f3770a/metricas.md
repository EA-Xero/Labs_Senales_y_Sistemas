| Métrica | Valor |
|---|---|
| experimento | senales_elementales |
| tipo | triangular |
| amplitud | 1.0 |
| t0 | 0.0 |
| fs | 500.0 |
| duracion | 3.0 |
| sigma | -1.0 |
| frecuencia | 2.0 |
| ancho | 0.5 |
| n_muestras | 1500 |
| energia | 0.16667199999999996 |
| potencia_media | 0.05555733333333332 |
| valor_max | 1.0 |
| valor_min | 0.0 |
| media | 0.08333333333333333 |
| rms | 0.23570603160151274 |
| Tipo de señal | triangular |
| Amplitud A | 1.0 |
| Desplazamiento t₀ [s] | 0.0 |
| Energía E = ∫x²dt | 0.166672 |
| Potencia media P | 0.055557 |
| Valor máximo | 1.0 |
| N° de muestras | 1500 |
