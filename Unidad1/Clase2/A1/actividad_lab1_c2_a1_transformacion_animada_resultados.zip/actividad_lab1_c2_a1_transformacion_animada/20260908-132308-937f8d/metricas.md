| Métrica | Valor |
|---|---|
| experimento | transformaciones_variable |
| base | doble_pulso |
| a | 2.0 |
| a_efectivo | 2.0 |
| t0 | 1.0 |
| reflexion | False |
| fs | 400.0 |
| n_muestras | 3200 |
| energia_original | 1.0858343750000001 |
| energia_transformada | 0.54416875 |
| energia_esperada | 0.5429171875000001 |
| error_relativo_energia | 0.0023052548875143394 |
| desplazamiento_efectivo_s | 0.5 |
| factor_compresion | 2.0 |
| hay_reflexion | False |
| max_original | 1.0 |
| max_transformada | 1.0 |
| Señal base | doble_pulso |
| Escala a (efectiva) | 2.0 |
| Desplazamiento t₀ | 1.0 |
| Desplazamiento efectivo t₀/a [s] | 0.5 |
| ¿Hay reflexión? | no |
| Energía x(t) | 1.085834 |
| Energía y(t) | 0.544169 |
| E_x/|a| (teórica) | 0.542917 |
| Error relativo de energía | 0.002305 |
