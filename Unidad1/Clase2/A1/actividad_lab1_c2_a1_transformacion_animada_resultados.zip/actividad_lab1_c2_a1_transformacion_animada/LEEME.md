# Bundle de resultados — simulador CIT2410

Evidencia exportada por el simulador para el informe de laboratorio.
Todos los valores provienen de la simulación ejecutada (cálculo real);
no hay datos precomputados.

| Corrida | Experimento | Actividad | Gráficos (PNG+SVG) |
|---|---|---|---|
| `20260908-132325-8882d4` | transformaciones_variable | A1 · Transformación general animada y(t)=x(a·t−t₀) | 1 |
| `20260908-132308-937f8d` | transformaciones_variable | A1 · Transformación general animada y(t)=x(a·t−t₀) | 1 |
| `20260907-204651-f3770a` | senales_elementales | A1 · Transformación general animada y(t)=x(a·t−t₀) | 1 |
| `20260907-204638-f73001` | senales_elementales | A1 · Transformación general animada y(t)=x(a·t−t₀) | 1 |
| `20260907-204159-4d69b6` | senales_elementales | A1 · Transformación general animada y(t)=x(a·t−t₀) | 1 |
| `20260907-204121-3bc603` | senales_elementales | A1 · Transformación general animada y(t)=x(a·t−t₀) | 1 |
| `20260907-204104-01b13a` | senales_elementales | A1 · Transformación general animada y(t)=x(a·t−t₀) | 1 |
| `20260907-204050-ba4451` | senales_elementales | A1 · Transformación general animada y(t)=x(a·t−t₀) | 1 |

## Contenido por corrida

- `resultado.json` — resultado completo (métricas y series).
- `metricas.csv` / `metricas.md` — tabla de valores de interés.
- `series.csv` — todas las series numéricas alineadas por índice.
- `config.json` — parámetros exactos con los que se corrió.
- `ficha_actividad.md` — objetivo, pasos, verificaciones y preguntas.
- `graficos/*.png` y `graficos/*.svg` — todas las figuras en ambos formatos.
