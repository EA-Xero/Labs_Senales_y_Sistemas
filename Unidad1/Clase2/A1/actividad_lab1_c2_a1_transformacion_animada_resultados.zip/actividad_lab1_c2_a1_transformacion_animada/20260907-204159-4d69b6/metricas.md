| Métrica | Valor |
|---|---|
| experimento | senales_elementales |
| tipo | triangular |
| amplitud | 2.0 |
| t0 | 0.0 |
| fs | 500.0 |
| duracion | 3.0 |
| sigma | -1.0 |
| frecuencia | 2.0 |
| ancho | 1.0 |
| n_muestras | 1500 |
| energia | 1.3333439999999999 |
| potencia_media | 0.44444799999999995 |
| valor_max | 2.0 |
| valor_min | 0.0 |
| media | 0.3333333333333333 |
| rms | 0.6666693333279999 |
| Tipo de señal | triangular |
| Amplitud A | 2.0 |
| Desplazamiento t₀ [s] | 0.0 |
| Energía E = ∫x²dt | 1.333344 |
| Potencia media P | 0.444448 |
| Valor máximo | 2.0 |
| N° de muestras | 1500 |
