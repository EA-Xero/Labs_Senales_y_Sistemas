| Métrica | Valor |
|---|---|
| experimento | senales_elementales |
| tipo | triangular |
| amplitud | 1.0 |
| t0 | 2.0 |
| fs | 500.0 |
| duracion | 3.0 |
| sigma | -1.0 |
| frecuencia | 2.0 |
| ancho | 1.0 |
| n_muestras | 1500 |
| energia | 0.16566800000000004 |
| potencia_media | 0.05522266666666668 |
| valor_max | 0.9960000000000004 |
| valor_min | 0.0 |
| media | 0.08299999999999999 |
| rms | 0.23499503540855216 |
| Tipo de señal | triangular |
| Amplitud A | 1.0 |
| Desplazamiento t₀ [s] | 2.0 |
| Energía E = ∫x²dt | 0.165668 |
| Potencia media P | 0.055223 |
| Valor máximo | 0.996 |
| N° de muestras | 1500 |
