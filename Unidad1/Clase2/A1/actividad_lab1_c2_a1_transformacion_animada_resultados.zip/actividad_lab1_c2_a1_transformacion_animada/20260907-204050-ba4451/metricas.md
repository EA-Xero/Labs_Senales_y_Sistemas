| Métrica | Valor |
|---|---|
| experimento | senales_elementales |
| tipo | triangular |
| amplitud | 1.0 |
| t0 | 0.0 |
| fs | 500.0 |
| duracion | 3.0 |
| sigma | -1.0 |
| frecuencia | 2.0 |
| ancho | 1.0 |
| n_muestras | 1500 |
| energia | 0.33333599999999997 |
| potencia_media | 0.11111199999999999 |
| valor_max | 1.0 |
| valor_min | 0.0 |
| media | 0.16666666666666666 |
| rms | 0.33333466666399997 |
| Tipo de señal | triangular |
| Amplitud A | 1.0 |
| Desplazamiento t₀ [s] | 0.0 |
| Energía E = ∫x²dt | 0.333336 |
| Potencia media P | 0.111112 |
| Valor máximo | 1.0 |
| N° de muestras | 1500 |
