# Actividad guiada: A1 · Transformación general animada y(t)=x(a·t−t₀)
Laboratorio 1 · Unidad 1 · Clase 2 (Transformación de la variable independiente)
#### A1 · Transformación general animada y(t)=x(a·t−t₀)  ·  10 min
*Experimento:* `transformaciones_variable`

**Objetivo.** Ver la transformación construirse y predecir el soporte antes de mirar el resultado.

**Procedimiento**

1. Antes de lanzar, escribe en el cuaderno el soporte y el máximo esperados.
2. Lanza la corrida y compara tu predicción con la medición del simulador.
3. Repite con la variante reflejada (a<0) y describe qué le pasó al retardo.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| El soporte medido coincide con el predicho por factorización de a | Figura PNG/SVG con la señal original y la transformada |

**Preguntas de análisis (van al informe)**

- ¿Por qué el máximo aparece en (τ+t₀)/a y no en t₀?

**Errores frecuentes**

- Escalar y desplazar sin factorizar a (síntoma: el máximo aparece en t₀).
