# Actividad guiada: A3 · Barrido de escalado con t₀ = 0: Ey = Ex/|a|
Laboratorio 1 · Unidad 1 · Clase 2 (Transformación de la variable independiente)
#### A3 · Barrido de escalado con t₀ = 0: Ey = Ex/|a|  ·  15 min
*Experimento:* `barrido_transformaciones`

**Objetivo.** Medir cómo el escalado reparte la energía y graficar la energía medida contra 1/|a| (debe salir una recta de pendiente Ex).

**Procedimiento**

1. Lanza el barrido de escalado con a entre 0,25 y 4.
2. Abre el gráfico «energía medida frente a 1/|a|» y comprueba la linealidad.
3. Repite con la variante de a negativos: comprimir y reflejar a la vez.
4. Comprueba que la potencia media no cambia en la variante senoidal.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Ey ≈ Ex/|a| en todo el barrido (error máx ≤ tolerancia) | Gráfico energía vs 1/|a| en PNG y SVG |
| Py ≈ Px en la señal periódica | Tabla CSV de potencias |

**Preguntas de análisis (van al informe)**

- ¿Qué pendiente obtuvo en el gráfico E vs 1/|a| y con qué la identifica?
- ¿Por qué la potencia media es invariante al escalado?

**Errores frecuentes**

- No subir fs antes de comprimir: la señal comprimida pierde forma.
- Ventana demasiado corta: la energía medida no alcanza a converger.
