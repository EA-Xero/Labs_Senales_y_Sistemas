# Bundle de resultados — simulador CIT2410

Evidencia exportada por el simulador para el informe de laboratorio.
Todos los valores provienen de la simulación ejecutada (cálculo real);
no hay datos precomputados.

| Corrida | Experimento | Actividad | Gráficos (PNG+SVG) |
|---|---|---|---|
| `20260908-133815-07fe3c` | barrido_transformaciones | A3 · Barrido de escalado con t₀ = 0: Ey = Ex/|a| | 4 |
| `20260908-133754-39565e` | barrido_transformaciones | A3 · Barrido de escalado con t₀ = 0: Ey = Ex/|a| | 4 |
| `20260908-133658-9f3756` | barrido_transformaciones | A3 · Barrido de escalado con t₀ = 0: Ey = Ex/|a| | 4 |

## Contenido por corrida

- `resultado.json` — resultado completo (métricas y series).
- `metricas.csv` / `metricas.md` — tabla de valores de interés.
- `series.csv` — todas las series numéricas alineadas por índice.
- `config.json` — parámetros exactos con los que se corrió.
- `ficha_actividad.md` — objetivo, pasos, verificaciones y preguntas.
- `graficos/*.png` y `graficos/*.svg` — todas las figuras en ambos formatos.
