| Métrica | Valor |
|---|---|
| experimento | barrido_transformaciones |
| senal_base | senoidal |
| modo_barrido | escalado |
| fs | 4000.0 |
| n_pasos | 9 |
| energia_base_Ex | 6.0 |
| potencia_base_Px | 0.5 |
| tau_maximo_base_s | -5.875 |
| error_max_energia_rel | 3.0 |
| error_max_pico_s | 18.0 |
| error_max_potencia_rel | 0.009226357831875864 |
| verificacion_Ey_igual_Ex_sobre_abs_a | False |
| verificacion_corrimiento_efectivo | False |
| verificacion_potencia_invariante | True |
| verificacion_energia_invariante_al_desplazamiento | False |
| Señal base | senoidal |
| Barrido | escalado |
| E_x (base) | 6.0 |
| P_x (base) | 0.5 |
| Máximo de la base τ [s] | -5.875 |
| Error máximo en E_y vs E_x/|a| | 3.0 |
| Error máximo en la posición del máximo [s] | 18.0 |
| Error máximo en P_y vs P_x | 0.009226 |
| ✔ Ey = Ex/|a| | False |
| ✔ máximo en (τ+t₀)/a | False |
| ✔ potencia invariante | True |
