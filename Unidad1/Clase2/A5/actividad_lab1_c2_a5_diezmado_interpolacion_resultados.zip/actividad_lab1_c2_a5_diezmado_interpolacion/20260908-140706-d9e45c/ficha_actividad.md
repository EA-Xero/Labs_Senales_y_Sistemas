# Actividad guiada: A5 · El caso discreto: diezmar por M, interpolar por L
Laboratorio 1 · Unidad 1 · Clase 2 (Transformación de la variable independiente)
#### A5 · El caso discreto: diezmar por M, interpolar por L  ·  15 min
*Experimento:* `diezmado_interpolacion`

**Objetivo.** Comprobar que el escalado discreto no es reversible: diezmar sin filtro produce solapamiento, e interpolar sin filtro deja imágenes espectrales.

**Procedimiento**

1. Lanza la corrida principal (con los dos filtros activos) y anota el error RMS de reconstrucción.
2. Repite con la variante sin filtro anti-solapamiento: compara la frecuencia aparente medida con la fórmula de plegado.
3. Repite sin filtro de interpolación y observa las imágenes en el espectro.
4. Confirma que la reflexión y el desplazamiento entero sí son exactos (error de ida y vuelta nulo).

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| f aparente medida = |f − k·fs/M| (error ≈ resolución de la DFT) | Tabla CSV + espectro tras diezmar |
| Error de ida y vuelta de reflexión y desplazamiento < 1e−12 | Tabla CSV de reversibilidad |

**Preguntas de análisis (van al informe)**

- ¿Qué fs mínima habría necesitado para diezmar por M sin solapamiento?
- ¿Por qué interpolar «inventa» muestras y diezmar las «pierde»?
