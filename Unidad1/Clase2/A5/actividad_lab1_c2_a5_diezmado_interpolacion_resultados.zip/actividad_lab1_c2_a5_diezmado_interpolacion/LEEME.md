# Bundle de resultados — simulador CIT2410

Evidencia exportada por el simulador para el informe de laboratorio.
Todos los valores provienen de la simulación ejecutada (cálculo real);
no hay datos precomputados.

| Corrida | Experimento | Actividad | Gráficos (PNG+SVG) |
|---|---|---|---|
| `20260908-140843-f3f8fa` | diezmado_interpolacion | A5 · El caso discreto: diezmar por M, interpolar por L | 6 |
| `20260908-140801-30a84d` | diezmado_interpolacion | A5 · El caso discreto: diezmar por M, interpolar por L | 6 |
| `20260908-140706-d9e45c` | diezmado_interpolacion | A5 · El caso discreto: diezmar por M, interpolar por L | 6 |

## Contenido por corrida

- `resultado.json` — resultado completo (métricas y series).
- `metricas.csv` / `metricas.md` — tabla de valores de interés.
- `series.csv` — todas las series numéricas alineadas por índice.
- `config.json` — parámetros exactos con los que se corrió.
- `ficha_actividad.md` — objetivo, pasos, verificaciones y preguntas.
- `graficos/*.png` y `graficos/*.svg` — todas las figuras en ambos formatos.
