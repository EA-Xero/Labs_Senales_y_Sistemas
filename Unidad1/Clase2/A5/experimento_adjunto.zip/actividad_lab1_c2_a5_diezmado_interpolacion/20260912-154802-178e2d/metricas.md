| Métrica | Valor |
|---|---|
| experimento | diezmado_interpolacion |
| senal_base | senoidal |
| fs | 8000.0 |
| M | 4 |
| L | 4 |
| fs_tras_diezmar | 2000.0 |
| filtro_anti_solapamiento | True |
| filtro_de_interpolacion | False |
| taps_filtro | 64 |
| f_dominante_original_hz | 300.0 |
| f_aparente_medida_hz | 300.0 |
| f_aparente_teorica_hz | 300.0 |
| error_formula_plegado_hz | 0.0 |
| hubo_solapamiento | False |
| error_rms_reconstruccion | 0.612377280225413 |
| error_rms_relativo | 0.612377280225413 |
| error_reflexion_ida_y_vuelta | 0.0 |
| error_desplazamiento_ida_y_vuelta | 0.0 |
| reflexion_y_desplazamiento_exactos | True |
| n_muestras_original | 1600 |
| n_muestras_diezmada | 400 |
| n_muestras_reconstruida | 1600 |
| Señal | senoidal |
| fs [Hz] | 8000.0 |
| M (diezmado) | 4 |
| L (interpolación) | 4 |
| Filtro anti-solapamiento | True |
| Filtro de interpolación | False |
| f dominante original [Hz] | 300.0 |
| f aparente medida [Hz] | 300.0 |
| f aparente por plegado [Hz] | 300.0 |
| ¿Hubo solapamiento? | False |
| Error RMS de reconstrucción | 0.612377 |
| Error RMS relativo | 0.612377 |
| Error reflexión ida y vuelta | 0.0 |
| Error desplazamiento ida y vuelta | 0.0 |
