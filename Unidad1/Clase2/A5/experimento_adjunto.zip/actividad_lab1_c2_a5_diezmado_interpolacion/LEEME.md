# Bundle de resultados — simulador CIT2410

Evidencia exportada por el simulador para el informe de laboratorio.
Todos los valores provienen de la simulación ejecutada (cálculo real);
no hay datos precomputados.

| Corrida | Experimento | Actividad | Gráficos (PNG+SVG) |
|---|---|---|---|
| `20260912-154832-82929c` | diezmado_interpolacion | A5 · El caso discreto: diezmar por M, interpolar por L | 6 |
| `20260912-154822-3875fd` | diezmado_interpolacion | A5 · El caso discreto: diezmar por M, interpolar por L | 6 |
| `20260912-154802-178e2d` | diezmado_interpolacion | A5 · El caso discreto: diezmar por M, interpolar por L | 6 |
| `20260912-154742-2502e4` | diezmado_interpolacion | A5 · El caso discreto: diezmar por M, interpolar por L | 6 |

## Contenido por corrida

- `resultado.json` — resultado completo (métricas y series).
- `metricas.csv` / `metricas.md` — tabla de valores de interés.
- `series.csv` — todas las series numéricas alineadas por índice.
- `config.json` — parámetros exactos con los que se corrió.
- `ficha_actividad.md` — objetivo, pasos, verificaciones y preguntas.
- `graficos/*.png` y `graficos/*.svg` — todas las figuras en ambos formatos.
