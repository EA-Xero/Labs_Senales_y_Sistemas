| Métrica | Valor |
|---|---|
| experimento | clasificacion_sistemas |
| sistema | compresor |
| a | 2.0 |
| b | 0.0 |
| retardo | 2 |
| ventana | 5 |
| f0 | 0.05 |
| amplitud | 1.0 |
| n_muestras | 64 |
| semilla | 11 |
| entrada | aleatoria |
| energia_salida | 27.530929933782936 |
| ganancia_dc | 1.0 |
| lineal | True |
| evidencia_lineal | 0.0 |
| invariante | False |
| evidencia_invariante | 1.429357964817812 |
| sin_memoria | False |
| evidencia_sin_memoria | 1.0 |
| causal | False |
| evidencia_causal | 1.0 |
| invertible | False |
| evidencia_invertible | 32.0 |
| estable | True |
| evidencia_estable | 1.0 |
| Sistema | compresor |
| Lineal | sí (evidencia=0; ‖T{αx₁+βx₂} − (αT{x₁}+βT{x₂})‖∞ relativo) |
| Invariante en el tiempo | no (evidencia=1.43; comparación con desplazamiento n₀=8) |
| Sin memoria | no (evidencia=1; perturbación en n=32) |
| Causal | no (evidencia=1; fuga hacia n<32 (0 ⇒ causal)) |
| Invertible | no (evidencia=32; rango de la matriz 64×64 del sistema) |
| Estable (BIBO) | sí (evidencia=1; razón de picos con entrada acotada 4× más larga) |
