| Métrica | Valor |
|---|---|
| experimento | clasificacion_sistemas |
| sistema | acumulador |
| a | 2.0 |
| b | 0.0 |
| retardo | 2 |
| ventana | 5 |
| f0 | 0.05 |
| amplitud | 1.0 |
| n_muestras | 64 |
| semilla | 11 |
| entrada | aleatoria |
| energia_salida | 682.9836263080776 |
| ganancia_dc | 64.0 |
| lineal | True |
| evidencia_lineal | 6.128285697432559e-16 |
| invariante | True |
| evidencia_invariante | 0.0 |
| sin_memoria | False |
| evidencia_sin_memoria | 32.0 |
| causal | True |
| evidencia_causal | 0.0 |
| invertible | True |
| evidencia_invertible | 64.0 |
| estable | False |
| evidencia_estable | 4.0 |
| Sistema | acumulador |
| Lineal | sí (evidencia=6.13e-16; ‖T{αx₁+βx₂} − (αT{x₁}+βT{x₂})‖∞ relativo) |
| Invariante en el tiempo | sí (evidencia=0; comparación con desplazamiento n₀=8) |
| Sin memoria | no (evidencia=32; perturbación en n=32) |
| Causal | sí (evidencia=0; fuga hacia n<32 (0 ⇒ causal)) |
| Invertible | sí (evidencia=64; rango de la matriz 64×64 del sistema) |
| Estable (BIBO) | no (evidencia=4; razón de picos con entrada acotada 4× más larga) |
