| Métrica | Valor |
|---|---|
| experimento | clasificacion_sistemas |
| sistema | escalado_offset |
| a | 2.0 |
| b | 0.0 |
| retardo | 2 |
| ventana | 5 |
| f0 | 0.05 |
| amplitud | 1.0 |
| n_muestras | 64 |
| semilla | 11 |
| entrada | aleatoria |
| energia_salida | 190.56895091076223 |
| ganancia_dc | 2.0 |
| lineal | True |
| evidencia_lineal | 0.0 |
| invariante | True |
| evidencia_invariante | 0.0 |
| sin_memoria | True |
| evidencia_sin_memoria | 1.0 |
| causal | True |
| evidencia_causal | 0.0 |
| invertible | True |
| evidencia_invertible | 64.0 |
| estable | True |
| evidencia_estable | 1.0 |
| Sistema | escalado_offset |
| Lineal | sí (evidencia=0; ‖T{αx₁+βx₂} − (αT{x₁}+βT{x₂})‖∞ relativo) |
| Invariante en el tiempo | sí (evidencia=0; comparación con desplazamiento n₀=8) |
| Sin memoria | sí (evidencia=1; perturbación en n=32) |
| Causal | sí (evidencia=0; fuga hacia n<32 (0 ⇒ causal)) |
| Invertible | sí (evidencia=64; rango de la matriz 64×64 del sistema) |
| Estable (BIBO) | sí (evidencia=1; razón de picos con entrada acotada 4× más larga) |
