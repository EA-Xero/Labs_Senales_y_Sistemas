# Bundle de resultados — simulador CIT2410

Evidencia exportada por el simulador para el informe de laboratorio.
Todos los valores provienen de la simulación ejecutada (cálculo real);
no hay datos precomputados.

| Corrida | Experimento | Actividad | Gráficos (PNG+SVG) |
|---|---|---|---|
| `20260908-144022-441cac` | clasificacion_sistemas | A3 · Clasificación de sistemas: seis propiedades medidas | 2 |
| `20260908-144004-d4cddf` | clasificacion_sistemas | A3 · Clasificación de sistemas: seis propiedades medidas | 2 |
| `20260908-143944-8b3988` | clasificacion_sistemas | A3 · Clasificación de sistemas: seis propiedades medidas | 2 |
| `20260908-143918-6c594b` | clasificacion_sistemas | A3 · Clasificación de sistemas: seis propiedades medidas | 2 |

## Contenido por corrida

- `resultado.json` — resultado completo (métricas y series).
- `metricas.csv` / `metricas.md` — tabla de valores de interés.
- `series.csv` — todas las series numéricas alineadas por índice.
- `config.json` — parámetros exactos con los que se corrió.
- `ficha_actividad.md` — objetivo, pasos, verificaciones y preguntas.
- `graficos/*.png` y `graficos/*.svg` — todas las figuras en ambos formatos.
