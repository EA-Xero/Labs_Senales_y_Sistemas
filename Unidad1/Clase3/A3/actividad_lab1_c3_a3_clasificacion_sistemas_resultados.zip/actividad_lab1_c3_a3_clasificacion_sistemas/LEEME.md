# Bundle de resultados — simulador CIT2410

Evidencia exportada por el simulador para el informe de laboratorio.
Todos los valores provienen de la simulación ejecutada (cálculo real);
no hay datos precomputados.

| Corrida | Experimento | Actividad | Gráficos (PNG+SVG) |
|---|---|---|---|
| `20260910-173823-a8519d` | clasificacion_sistemas | A3 · Clasificación de sistemas: seis propiedades medidas | 2 |
| `20260910-173807-108c6f` | clasificacion_sistemas | A3 · Clasificación de sistemas: seis propiedades medidas | 2 |
| `20260910-173752-a70813` | clasificacion_sistemas | A3 · Clasificación de sistemas: seis propiedades medidas | 2 |
| `20260910-173731-f704da` | clasificacion_sistemas | A3 · Clasificación de sistemas: seis propiedades medidas | 2 |
| `20260910-173715-f807b9` | clasificacion_sistemas | A3 · Clasificación de sistemas: seis propiedades medidas | 2 |

## Contenido por corrida

- `resultado.json` — resultado completo (métricas y series).
- `metricas.csv` / `metricas.md` — tabla de valores de interés.
- `series.csv` — todas las series numéricas alineadas por índice.
- `config.json` — parámetros exactos con los que se corrió.
- `ficha_actividad.md` — objetivo, pasos, verificaciones y preguntas.
- `graficos/*.png` y `graficos/*.svg` — todas las figuras en ambos formatos.
