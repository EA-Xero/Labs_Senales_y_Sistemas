# Actividad guiada: A3 · Clasificación de sistemas: seis propiedades medidas
Laboratorio 1 · Unidad 1 · Clase 3 (Señales básicas y clasificación de sistemas)
#### A3 · Clasificación de sistemas: seis propiedades medidas  ·  25 min
*Experimento:* `clasificacion_sistemas`

**Objetivo.** Obtener los booleanos por propiedad, la respuesta al impulso estimada h[n] y la ganancia DC de varios sistemas de prueba, y explicar cada resultado.

**Procedimiento**

1. Lanza la actividad: cubre sistemas lineal-con-offset, acumulador, media móvil y compresor.
2. Para cada uno, anota los seis booleanos y contrasta con la teoría.
3. Estima h[n] y comprueba causalidad (h[n]=0 para n<0) y BIBO (sumabilidad absoluta).
4. Exporta el **bundle ZIP de la actividad**: es la evidencia central del informe del Laboratorio 1.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| y = a·x + b es lineal sólo si b = 0 | Tabla CSV de booleanos |
| El acumulador es con memoria y no BIBO estable | Tabla CSV + figura de h[n] |
| El compresor (x[a·n]) no es invariante en el tiempo | Tabla CSV de invarianza |

**Preguntas de análisis (van al informe)**

- ¿Qué prueba numérica delata la falta de invarianza y por qué?
- ¿Cómo se lee la estabilidad BIBO en h[n] estimada?
- ¿Qué sistema de los probados sería implementable en tiempo real y por qué?

**Errores frecuentes**

- Concluir linealidad probando con una sola entrada.
- Confundir «sin memoria» con «causal»: son propiedades distintas.
