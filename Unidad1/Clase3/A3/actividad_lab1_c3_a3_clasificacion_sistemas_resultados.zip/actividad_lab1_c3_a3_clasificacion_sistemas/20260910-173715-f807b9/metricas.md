| Métrica | Valor |
|---|---|
| experimento | clasificacion_sistemas |
| sistema | escalado_offset |
| a | 2.0 |
| b | 1.0 |
| retardo | 2 |
| ventana | 5 |
| f0 | 0.05 |
| amplitud | 1.0 |
| n_muestras | 64 |
| semilla | 11 |
| entrada | aleatoria |
| energia_salida | 240.76409542864633 |
| ganancia_dc | 66.0 |
| lineal | False |
| evidencia_lineal | 0.12544913749754413 |
| invariante | True |
| evidencia_invariante | 0.0 |
| sin_memoria | True |
| evidencia_sin_memoria | 1.0 |
| causal | True |
| evidencia_causal | 0.0 |
| invertible | True |
| evidencia_invertible | 1.5868350082286415 |
| estable | True |
| evidencia_estable | 1.0 |
| Sistema | escalado_offset |
| Lineal | no (evidencia=0.125; ‖T{αx₁+βx₂} − (αT{x₁}+βT{x₂})‖∞ relativo) |
| Invariante en el tiempo | sí (evidencia=0; comparación con desplazamiento n₀=8) |
| Sin memoria | sí (evidencia=1; perturbación en n=32) |
| Causal | sí (evidencia=0; fuga hacia n<32 (0 ⇒ causal)) |
| Invertible | sí (evidencia=1.59; comparación de T{x} y T{−x}) |
| Estable (BIBO) | sí (evidencia=1; razón de picos con entrada acotada 4× más larga) |
