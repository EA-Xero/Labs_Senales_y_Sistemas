# Actividad guiada: A2 · Exponencial compleja, aliasing discreto y autofunciones
Laboratorio 1 · Unidad 1 · Clase 3 (Señales básicas y clasificación de sistemas)
#### A2 · Exponencial compleja, aliasing discreto y autofunciones  ·  15 min
*Experimento:* `exponencial_compleja_euler`

**Objetivo.** Comprobar Euler, la unicidad de ω módulo 2π y que un LTI sólo cambia amplitud y fase de e^{jω₀n} (autovalor H(e^{jω₀})).

**Procedimiento**

1. Lanza la corrida principal con el promediador móvil.
2. Comprueba que las secuencias de ω₀ y ω₀+2π son idénticas muestra a muestra.
3. Compara |H| y ∠H medidas en régimen con los valores analíticos.
4. Repite con el IIR de primer orden y con el diferenciador.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Error de la identidad de Euler ≈ 0 (precisión numérica) | Tabla CSV de errores |
| Error máximo entre e^{jω₀n} y e^{j(ω₀+2π)n} ≈ 0 | Figura de las dos secuencias superpuestas |
| |H_medida − H_teórica| ≤ tolerancia | Tabla CSV del autovalor |

**Preguntas de análisis (van al informe)**

- ¿Por qué toda frecuencia discreta se puede representar en [−π, π)?
- ¿Qué significa que e^{jω₀n} sea autofunción para el análisis de Fourier?
