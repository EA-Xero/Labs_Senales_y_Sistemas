| Métrica | Valor |
|---|---|
| experimento | exponencial_compleja_euler |
| amplitud | 1.0 |
| sigma | -0.5 |
| frecuencia_hz | 3.0 |
| fs | 1000.0 |
| omega0_rad_muestra | 0.7853981633974483 |
| omega0_sobre_2pi | 0.125 |
| sistema_lti | diferenciador |
| orden | 8 |
| error_max_identidad_euler | 0.0 |
| error_max_unicidad_2pi | 8.525522460102662e-14 |
| periodo_discreto_N | 8 |
| periodica_en_tiempo_discreto | True |
| error_repeticion_periodo | 7.379434555813744e-15 |
| ganancia_H_medida | 0.7653668647301796 |
| ganancia_H_teorica | 0.7653668647301795 |
| fase_H_medida_rad | 1.1780972450961726 |
| fase_H_teorica_rad | 1.1780972450961724 |
| error_autovalor_H | 1.1102230246251565e-16 |
| verificacion_euler | True |
| verificacion_unicidad_2pi | True |
| verificacion_autofuncion_lti | True |
| Error máximo de la identidad de Euler | 0.0 |
| Error máximo de unicidad módulo 2π | 0.0 |
| ω₀/2π | 0.125 |
| N discreto teórico | 8 |
| ¿Periódica en tiempo discreto? | True |
| |H(e^{jω₀})| medida | 0.765367 |
| |H(e^{jω₀})| teórica | 0.765367 |
| ∠H medida [rad] | 1.178097 |
| ∠H teórica [rad] | 1.178097 |
| Error del autovalor |H_med − H_teo| | 0.0 |
