# Bundle de resultados — simulador CIT2410

Evidencia exportada por el simulador para el informe de laboratorio.
Todos los valores provienen de la simulación ejecutada (cálculo real);
no hay datos precomputados.

| Corrida | Experimento | Actividad | Gráficos (PNG+SVG) |
|---|---|---|---|
| `20260910-173356-42860b` | exponencial_compleja_euler | A2 · Exponencial compleja, aliasing discreto y autofunciones | 3 |
| `20260910-173342-5cfac2` | exponencial_compleja_euler | A2 · Exponencial compleja, aliasing discreto y autofunciones | 3 |
| `20260910-173328-437791` | exponencial_compleja_euler | A2 · Exponencial compleja, aliasing discreto y autofunciones | 3 |
| `20260910-173310-5f327b` | exponencial_compleja_euler | A2 · Exponencial compleja, aliasing discreto y autofunciones | 3 |

## Contenido por corrida

- `resultado.json` — resultado completo (métricas y series).
- `metricas.csv` / `metricas.md` — tabla de valores de interés.
- `series.csv` — todas las series numéricas alineadas por índice.
- `config.json` — parámetros exactos con los que se corrió.
- `ficha_actividad.md` — objetivo, pasos, verificaciones y preguntas.
- `graficos/*.png` y `graficos/*.svg` — todas las figuras en ambos formatos.
