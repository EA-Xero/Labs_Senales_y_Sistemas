| Métrica | Valor |
|---|---|
| experimento | escalon_rampa_impulso |
| fs | 5000.0 |
| amplitud | 1.0 |
| ancho_pulso_s | 1.0 |
| error_max_escalon_acumulado | 0.0 |
| error_max_impulso_diferencia | 0.0 |
| error_max_rampa_integrada | 0.00020000000000042206 |
| error_relativo_rampa | 6.667111140756786e-05 |
| error_max_pulso_diferencia_escalones | 1.0 |
| energia_pulso_medida | 1.0 |
| energia_pulso_teorica_A2T | 1.0 |
| error_relativo_energia_pulso | 0.0 |
| potencia_media_escalon | 0.75 |
| fraccion_de_eje_con_t_mayor_igual_0 | 0.75 |
| area_impulso_unitario | 1.0 |
| area_impulso_escalado | 0.5 |
| area_teorica_1_sobre_abs_a | 0.5 |
| error_relativo_area_escalado | 0.0 |
| integral_muestreo_medida | -0.159501743246032 |
| valor_exacto_x_en_t0 | -0.1564344650402306 |
| error_relativo_propiedad_muestreo | 0.019607432447910963 |
| verificacion_u_es_acumulacion_de_delta | True |
| verificacion_delta_es_diferencia_de_u | True |
| verificacion_rampa_es_integral_de_u | True |
| verificacion_pulso_diferencia_escalones | False |
| verificacion_energia_pulso_A2T | True |
| verificacion_peso_delta_escalado | True |
| verificacion_propiedad_muestreo | True |
| Error máx |Σδ − u| | 0.0 |
| Error máx |u[n]−u[n−1] − δ| | 0.0 |
| Error relativo de la rampa integrada | 6.667e-05 |
| Error máx del pulso por diferencia de escalones | 1.0 |
| E medida del pulso | 1.0 |
| E teórica A²T | 1.0 |
| Potencia media del escalón (sobre la ventana) | 0.75 |
| Área medida de δ(a·t) | 0.5 |
| Área teórica 1/|a| | 0.5 |
| ∫x(t)δ(t−t₀)dt medida | -0.159502 |
| x(t₀) exacta | -0.156434 |
| Error relativo de la propiedad de muestreo | 0.019607 |
