# Actividad guiada: A1 · La escalera δ → u → r y la propiedad de muestreo
Laboratorio 1 · Unidad 1 · Clase 3 (Señales básicas y clasificación de sistemas)
#### A1 · La escalera δ → u → r y la propiedad de muestreo  ·  15 min
*Experimento:* `escalon_rampa_impulso`

**Objetivo.** Verificar con números las relaciones entre las señales elementales, incluido el peso del impulso escalado y el muestreo.

**Procedimiento**

1. Lanza la actividad y sigue los cinco cuadros de la vista en vivo.
2. Comprueba que E del pulso coincide con A²T y que u[n]−u[n−1] devuelve δ[n].
3. Contrasta el área medida de δ(a·t) con 1/|a| en las variantes.
4. Verifica ∫x(t)δ(t−t₀)dt = x(t₀) y explica el error residual.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| E del pulso = A²T (error relativo ≤ tolerancia) | Tabla CSV de valores |
| Área de δ(a·t) = 1/|a| | Tabla CSV del escalado del impulso |
| Propiedad de muestreo con error relativo pequeño | Tabla CSV + figura de x(t) y la aproximación de δ |

**Preguntas de análisis (van al informe)**

- ¿De dónde viene el error residual de la propiedad de muestreo?
- ¿Por qué el escalón es señal de potencia y el pulso de energía?
