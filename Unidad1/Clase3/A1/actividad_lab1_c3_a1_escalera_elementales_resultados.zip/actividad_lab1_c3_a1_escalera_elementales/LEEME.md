# Bundle de resultados — simulador CIT2410

Evidencia exportada por el simulador para el informe de laboratorio.
Todos los valores provienen de la simulación ejecutada (cálculo real);
no hay datos precomputados.

| Corrida | Experimento | Actividad | Gráficos (PNG+SVG) |
|---|---|---|---|
| `20260908-143447-da6be0` | escalon_rampa_impulso | A1 · La escalera δ → u → r y la propiedad de muestreo | 4 |

## Contenido por corrida

- `resultado.json` — resultado completo (métricas y series).
- `metricas.csv` / `metricas.md` — tabla de valores de interés.
- `series.csv` — todas las series numéricas alineadas por índice.
- `config.json` — parámetros exactos con los que se corrió.
- `ficha_actividad.md` — objetivo, pasos, verificaciones y preguntas.
- `graficos/*.png` y `graficos/*.svg` — todas las figuras en ambos formatos.
