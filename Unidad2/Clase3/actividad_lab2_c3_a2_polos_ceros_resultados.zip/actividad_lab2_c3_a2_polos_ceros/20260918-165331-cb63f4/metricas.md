| Métrica | Valor |
|---|---|
| experimento | mapa_polos_ceros |
| sistema | segundo_orden |
| formula | H(s) = K·ωₙ² / (s² + 2ζωₙ·s + ωₙ²) |
| transferencia | H(s) = [16] / [1·s^2 + 0.8·s + 16] |
| zeta | 0.1 |
| wn | 4.0 |
| tau | 0.5 |
| ganancia | 1.0 |
| cero | 2.0 |
| n_polos | 2 |
| n_ceros | 0 |
| estable | True |
| oscilatorio | True |
| tipo_sistema | 0 |
| max_parte_real | -0.40000000000000024 |
| constante_tiempo_dominante_s | 2.4999999999999987 |
| amortiguamiento_min | 0.10000000000000006 |
| wn_max_rad_s | 4.0 |
| ganancia_dc | 1.0 |
| decaimiento_medido | 0.04496323977723877 |
| decaimiento_teorico | 0.2023007150930105 |
| Sistema | segundo_orden |
| H(s) | H(s) = [16] / [1·s^2 + 0.8·s + 16] |
| N° de polos | 2 |
| N° de ceros | 0 |
| ¿Estable (BIBO)? | sí |
| ¿Oscilatorio? | sí |
| Tipo (integradores) | 0 |
| máx Re{p} [1/s] | -0.4 |
| Constante de tiempo dominante [s] | 2.5 |
| Amortiguamiento mínimo | 0.1 |
| |p| máximo [rad/s] | 4.0 |
| Polos | -0.4+3.98j, -0.4-3.98j |
| Ceros | — |
