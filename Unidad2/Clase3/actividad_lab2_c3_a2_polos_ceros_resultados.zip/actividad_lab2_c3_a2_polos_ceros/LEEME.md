# Bundle de resultados — simulador CIT2410

Evidencia exportada por el simulador para el informe de laboratorio.
Todos los valores provienen de la simulación ejecutada (cálculo real);
no hay datos precomputados.

| Corrida | Experimento | Actividad | Gráficos (PNG+SVG) |
|---|---|---|---|
| `20260918-165419-af57ce` | mapa_polos_ceros | A2 · Migración de polos y frontera de estabilidad | 3 |
| `20260918-165419-9e669d` | mapa_polos_ceros | A2 · Migración de polos y frontera de estabilidad | 3 |
| `20260918-165419-6b4bfa` | mapa_polos_ceros | A2 · Migración de polos y frontera de estabilidad | 3 |
| `20260918-165419-45f8ee` | mapa_polos_ceros | A2 · Migración de polos y frontera de estabilidad | 3 |
| `20260918-165419-3be292` | mapa_polos_ceros | A2 · Migración de polos y frontera de estabilidad | 2 |
| `20260918-165419-29f5b5` | mapa_polos_ceros | A2 · Migración de polos y frontera de estabilidad | 2 |
| `20260918-165419-0e0df5` | mapa_polos_ceros | A2 · Migración de polos y frontera de estabilidad | 3 |
| `20260918-165419-01ba0c` | mapa_polos_ceros | A2 · Migración de polos y frontera de estabilidad | 3 |
| `20260918-165331-eff3ea` | mapa_polos_ceros | A2 · Migración de polos y frontera de estabilidad | 3 |
| `20260918-165331-cb63f4` | mapa_polos_ceros | A2 · Migración de polos y frontera de estabilidad | 3 |
| `20260918-165331-6eaf39` | mapa_polos_ceros | A2 · Migración de polos y frontera de estabilidad | 2 |
| `20260918-165331-6b74b4` | mapa_polos_ceros | A2 · Migración de polos y frontera de estabilidad | 3 |

## Contenido por corrida

- `resultado.json` — resultado completo (métricas y series).
- `metricas.csv` / `metricas.md` — tabla de valores de interés.
- `series.csv` — todas las series numéricas alineadas por índice.
- `config.json` — parámetros exactos con los que se corrió.
- `ficha_actividad.md` — objetivo, pasos, verificaciones y preguntas.
- `graficos/*.png` y `graficos/*.svg` — todas las figuras en ambos formatos.
