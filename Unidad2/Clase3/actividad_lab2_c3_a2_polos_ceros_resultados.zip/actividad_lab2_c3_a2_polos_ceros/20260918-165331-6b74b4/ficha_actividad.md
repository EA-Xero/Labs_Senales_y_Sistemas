# Actividad guiada: A2 · Migración de polos y frontera de estabilidad
Laboratorio 2 · Unidad 2 · Clase 3 (Series de Fourier y respuesta en frecuencia)
#### A2 · Migración de polos y frontera de estabilidad  ·  15 min
*Experimento:* `mapa_polos_ceros`

**Objetivo.** Ver cómo la posición de los polos determina oscilación, amortiguamiento y estabilidad.

**Procedimiento**

1. Lanza la actividad y observa la migración de los polos en el plano s.
2. Relaciona la parte real con la velocidad de decaimiento e^{σt}.
3. Prueba la variante inestable y describe qué cambia en la respuesta.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Estable ⇔ todos los polos con parte real negativa | Figura del plano s + tabla CSV |
| Polos complejos conjugados ⇒ respuesta oscilatoria amortiguada | Figura de la respuesta temporal |

**Preguntas de análisis (van al informe)**

- ¿Qué polo domina la respuesta y por qué?
