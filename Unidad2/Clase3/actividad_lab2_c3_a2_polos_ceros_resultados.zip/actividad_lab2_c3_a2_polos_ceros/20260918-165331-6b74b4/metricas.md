| Métrica | Valor |
|---|---|
| experimento | mapa_polos_ceros |
| sistema | doble_polo |
| formula | H(s) = K / (τ·s + 1)² |
| transferencia | H(s) = [1] / [0.25·s^2 + 1·s + 1] |
| zeta | 0.5 |
| wn | 4.0 |
| tau | 0.5 |
| ganancia | 1.0 |
| cero | 2.0 |
| n_polos | 2 |
| n_ceros | 0 |
| estable | True |
| oscilatorio | False |
| tipo_sistema | 0 |
| max_parte_real | -2.0 |
| constante_tiempo_dominante_s | 0.5 |
| amortiguamiento_min | 1.0 |
| wn_max_rad_s | 2.0 |
| ganancia_dc | 1.0 |
| decaimiento_medido | 0.0073591617880383 |
| decaimiento_teorico | 0.0003388340833634261 |
| Sistema | doble_polo |
| H(s) | H(s) = [1] / [0.25·s^2 + 1·s + 1] |
| N° de polos | 2 |
| N° de ceros | 0 |
| ¿Estable (BIBO)? | sí |
| ¿Oscilatorio? | no |
| Tipo (integradores) | 0 |
| máx Re{p} [1/s] | -2.0 |
| Constante de tiempo dominante [s] | 0.5 |
| Amortiguamiento mínimo | 1.0 |
| |p| máximo [rad/s] | 2.0 |
| Polos | -2+0j, -2+0j |
| Ceros | — |
