| Métrica | Valor |
|---|---|
| experimento | mapa_polos_ceros |
| sistema | segundo_orden |
| formula | H(s) = K·ωₙ² / (s² + 2ζωₙ·s + ωₙ²) |
| transferencia | H(s) = [16] / [1·s^2 + 4·s + 16] |
| zeta | 0.5 |
| wn | 4.0 |
| tau | 0.5 |
| ganancia | 1.0 |
| cero | 2.0 |
| n_polos | 2 |
| n_ceros | 0 |
| estable | True |
| oscilatorio | True |
| tipo_sistema | 0 |
| max_parte_real | -2.0000000000000004 |
| constante_tiempo_dominante_s | 0.4999999999999999 |
| amortiguamiento_min | 0.5000000000000002 |
| wn_max_rad_s | 4.0 |
| ganancia_dc | 1.0 |
| decaimiento_medido | 0.0006846404268769916 |
| decaimiento_teorico | 0.0003388340833634255 |
| Sistema | segundo_orden |
| H(s) | H(s) = [16] / [1·s^2 + 4·s + 16] |
| N° de polos | 2 |
| N° de ceros | 0 |
| ¿Estable (BIBO)? | sí |
| ¿Oscilatorio? | sí |
| Tipo (integradores) | 0 |
| máx Re{p} [1/s] | -2.0 |
| Constante de tiempo dominante [s] | 0.5 |
| Amortiguamiento mínimo | 0.5 |
| |p| máximo [rad/s] | 4.0 |
| Polos | -2+3.464j, -2-3.464j |
| Ceros | — |
