| Métrica | Valor |
|---|---|
| experimento | mapa_polos_ceros |
| sistema | inestable |
| formula | H(s) = K / (τ·s − 1) |
| transferencia | H(s) = [1] / [0.5·s + -1] |
| zeta | 0.5 |
| wn | 4.0 |
| tau | 0.5 |
| ganancia | 1.0 |
| cero | 2.0 |
| n_polos | 1 |
| n_ceros | 0 |
| estable | False |
| oscilatorio | False |
| tipo_sistema | 0 |
| max_parte_real | 2.0 |
| constante_tiempo_dominante_s | 1e+30 |
| amortiguamiento_min | -1.0 |
| wn_max_rad_s | 2.0 |
| ganancia_dc | -1.0 |
| decaimiento_medido | 1.0 |
| decaimiento_teorico | 2951.2969594839183 |
| Sistema | inestable |
| H(s) | H(s) = [1] / [0.5·s + -1] |
| N° de polos | 1 |
| N° de ceros | 0 |
| ¿Estable (BIBO)? | no |
| ¿Oscilatorio? | no |
| Tipo (integradores) | 0 |
| máx Re{p} [1/s] | 2.0 |
| Constante de tiempo dominante [s] | ∞ |
| Amortiguamiento mínimo | -1.0 |
| |p| máximo [rad/s] | 2.0 |
| Polos | 2+0j |
| Ceros | — |
