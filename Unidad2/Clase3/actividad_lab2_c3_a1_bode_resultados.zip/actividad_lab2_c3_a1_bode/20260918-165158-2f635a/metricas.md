| Métrica | Valor |
|---|---|
| experimento | bode_transferencia |
| sistema | segundo_orden |
| formula | H(s) = K·ωₙ² / (s² + 2ζωₙ·s + ωₙ²) |
| transferencia | H(s) = [16] / [1·s^2 + 2.4·s + 16] |
| ganancia | 1.0 |
| tau | 0.5 |
| wn | 4.0 |
| zeta | 0.3 |
| cero | 1.0 |
| decada_min | -2 |
| decada_max | 3 |
| n_puntos | 400 |
| estable | True |
| ganancia_dc | 1.0 |
| ganancia_dc_db | 0.0 |
| ancho_banda_3db_rad_s | 5.880625988746757 |
| pico_magnitud_db | 4.845321638433309 |
| w_pico_rad_s | 3.60073348498562 |
| w_resonancia_teorica_rad_s | 3.622154055254967 |
| pico_teorico_db | 4.846561069116191 |
| margen_ganancia_db | 1e+30 |
| margen_fase_deg | 50.20818050044275 |
| w_cruce_fase_rad_s | 0.0 |
| w_cruce_ganancia_rad_s | 5.122499389946279 |
| margen_ganancia_infinito | True |
| fase_final_deg | -179.8624881930062 |
| pendiente_final_db_dec | -40.000540242101124 |
| error_control_vs_numpy | 0.0 |
| Sistema | segundo_orden |
| H(s) | H(s) = [16] / [1·s^2 + 2.4·s + 16] |
| Ganancia DC H(0) | 1.0 |
| Ancho de banda −3 dB [rad/s] | 5.880626 |
| Pico de magnitud [dB] | 4.8453 |
| ω del pico [rad/s] | 3.600733 |
| ω de resonancia teórica [rad/s] | 3.622154 |
| Margen de ganancia [dB] | ∞ (sin cruce de −180°) |
| Margen de fase [°] | 50.2082 |
| Fase en la última década [°] | -179.8625 |
| Error control vs NumPy | 0.0 |
