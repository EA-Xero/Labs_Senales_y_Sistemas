# Actividad guiada: A1 · Bode: ganancia, −3 dB y resonancia
Laboratorio 2 · Unidad 2 · Clase 3 (Series de Fourier y respuesta en frecuencia)
#### A1 · Bode: ganancia, −3 dB y resonancia  ·  15 min
*Experimento:* `bode_transferencia`

**Objetivo.** Medir magnitud y fase de H(jω) y las métricas que definen la velocidad y la resonancia del sistema.

**Procedimiento**

1. Lanza la corrida con el sistema de segundo orden.
2. Anota el ancho de banda de −3 dB y el pico de resonancia.
3. Repite con ζ pequeño y con ganancia ×10: comprueba el desplazamiento de ±20 dB y el crecimiento del pico.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Multiplicar K por 10 desplaza la magnitud +20 dB | resumen_corridas.csv de la actividad |
| El pico de resonancia aparece sólo si ζ < 0,707 | Gráfico de magnitud en dB |

**Preguntas de análisis (van al informe)**

- ¿Qué pendiente asintótica midió y cuántos polos la explican?
- ¿Cómo se relaciona el ancho de banda de −3 dB con el tiempo de subida?
