| Métrica | Valor |
|---|---|
| experimento | bode_transferencia |
| sistema | segundo_orden |
| formula | H(s) = K·ωₙ² / (s² + 2ζωₙ·s + ωₙ²) |
| transferencia | H(s) = [16] / [1·s^2 + 0.4·s + 16] |
| ganancia | 1.0 |
| tau | 0.5 |
| wn | 4.0 |
| zeta | 0.05 |
| cero | 1.0 |
| decada_min | -2 |
| decada_max | 3 |
| n_puntos | 400 |
| estable | True |
| ganancia_dc | 1.0 |
| ganancia_dc_db | 0.0 |
| ancho_banda_3db_rad_s | 6.229973732441841 |
| pico_magnitud_db | 19.73171005299094 |
| w_pico_rad_s | 4.0412553329506 |
| w_resonancia_teorica_rad_s | 3.9899874686520005 |
| pico_teorico_db | 20.01087095641214 |
| margen_ganancia_db | 1e+30 |
| margen_fase_deg | 8.109614455994176 |
| w_cruce_fase_rad_s | 0.0 |
| w_cruce_ganancia_rad_s | 5.642694391866354 |
| margen_ganancia_infinito | True |
| fase_final_deg | -179.97708132271828 |
| pendiente_final_db_dec | -40.00065554376884 |
| error_control_vs_numpy | 0.0 |
| Sistema | segundo_orden |
| H(s) | H(s) = [16] / [1·s^2 + 0.4·s + 16] |
| Ganancia DC H(0) | 1.0 |
| Ancho de banda −3 dB [rad/s] | 6.229974 |
| Pico de magnitud [dB] | 19.7317 |
| ω del pico [rad/s] | 4.041255 |
| ω de resonancia teórica [rad/s] | 3.989987 |
| Margen de ganancia [dB] | ∞ (sin cruce de −180°) |
| Margen de fase [°] | 8.1096 |
| Fase en la última década [°] | -179.9771 |
| Error control vs NumPy | 0.0 |
