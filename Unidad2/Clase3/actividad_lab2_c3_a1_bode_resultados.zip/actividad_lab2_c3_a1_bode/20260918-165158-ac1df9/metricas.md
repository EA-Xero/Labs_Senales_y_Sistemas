| Métrica | Valor |
|---|---|
| experimento | bode_transferencia |
| sistema | pasabanda |
| formula | H(s) = K·2ζωₙ·s / (s² + 2ζωₙ·s + ωₙ²) |
| transferencia | H(s) = [2.4·s] / [1·s^2 + 2.4·s + 16] |
| ganancia | 1.0 |
| tau | 0.5 |
| wn | 4.0 |
| zeta | 0.3 |
| cero | 1.0 |
| decada_min | -2 |
| decada_max | 3 |
| n_puntos | 400 |
| estable | True |
| ganancia_dc | 0.0 |
| ganancia_dc_db | 0.0 |
| ancho_banda_3db_rad_s | 1000.0 |
| pico_magnitud_db | -0.0050778892544438015 |
| w_pico_rad_s | 4.0412553329506 |
| w_resonancia_teorica_rad_s | 0.0 |
| pico_teorico_db | 0.0 |
| margen_ganancia_db | 1e+30 |
| margen_fase_deg | 1e+30 |
| w_cruce_fase_rad_s | 0.0 |
| w_cruce_ganancia_rad_s | 0.0 |
| margen_ganancia_infinito | True |
| fase_final_deg | -89.86248819300619 |
| pendiente_final_db_dec | -20.00054024209999 |
| error_control_vs_numpy | 0.0 |
| Sistema | pasabanda |
| H(s) | H(s) = [2.4·s] / [1·s^2 + 2.4·s + 16] |
| Ganancia DC H(0) | 0.0 |
| Ancho de banda −3 dB [rad/s] | 1000.0 |
| Pico de magnitud [dB] | -0.0051 |
| ω del pico [rad/s] | 4.041255 |
| ω de resonancia teórica [rad/s] | 0.0 |
| Margen de ganancia [dB] | ∞ (sin cruce de −180°) |
| Margen de fase [°] | ∞ |
| Fase en la última década [°] | -89.8625 |
| Error control vs NumPy | 0.0 |
