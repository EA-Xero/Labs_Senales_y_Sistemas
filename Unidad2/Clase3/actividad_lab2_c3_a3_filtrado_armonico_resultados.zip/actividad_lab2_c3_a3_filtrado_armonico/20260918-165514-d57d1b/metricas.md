| Métrica | Valor |
|---|---|
| experimento | filtrado_armonico |
| senal | cuadrada |
| sistema | segundo_orden |
| H_de_s | H(s) = [144] / [1·s^2 + 2.4·s + 144] |
| formula | H(s) = K·ωₙ² / (s² + 2ζωₙ·s + ωₙ²) |
| f0_hz | 1.0 |
| n_armonicos | 21 |
| fs | 2000.0 |
| ancho_banda_3db_hz | 2.9630287671479145 |
| armonicos_atenuados_mas_3db | 19 |
| thd_entrada_por_ciento | 45.934402866286476 |
| thd_salida_por_ciento | 16.507932897463505 |
| error_rms_prediccion | 0.0014359223199700887 |
| error_rms_relativo | 0.0007310153931525049 |
| error_max_relativo | 0.002264661616660325 |
| ganancia_dc | 1.0 |
| verificacion_superposicion_armonica | True |
| verificacion_sistema_no_crea_armonicos | True |
| Señal de entrada | cuadrada |
| Sistema | segundo_orden · H(s) = K·ωₙ² / (s² + 2ζωₙ·s + ωₙ²) |
| f₀ [Hz] | 1.0 |
| Armónicos considerados | 21 |
| Ancho de banda −3 dB [Hz] | 2.963 |
| Armónicos atenuados más de 3 dB | 19 |
| THD de la entrada [%] | 45.934 |
| THD de la salida [%] | 16.508 |
| Error RMS relativo predicción vs simulación | 0.000731 |
| Error máximo relativo | 0.002265 |
