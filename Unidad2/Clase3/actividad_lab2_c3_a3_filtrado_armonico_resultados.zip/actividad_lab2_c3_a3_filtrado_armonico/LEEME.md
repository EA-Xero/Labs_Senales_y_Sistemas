# Bundle de resultados — simulador CIT2410

Evidencia exportada por el simulador para el informe de laboratorio.
Todos los valores provienen de la simulación ejecutada (cálculo real);
no hay datos precomputados.

| Corrida | Experimento | Actividad | Gráficos (PNG+SVG) |
|---|---|---|---|
| `20260918-165514-d57d1b` | filtrado_armonico | A3 · Filtrar una señal periódica armónico por armónico | 4 |
| `20260918-165514-809ff0` | filtrado_armonico | A3 · Filtrar una señal periódica armónico por armónico | 4 |
| `20260918-165514-650058` | filtrado_armonico | A3 · Filtrar una señal periódica armónico por armónico | 4 |
| `20260918-165514-0cc756` | filtrado_armonico | A3 · Filtrar una señal periódica armónico por armónico | 4 |

## Contenido por corrida

- `resultado.json` — resultado completo (métricas y series).
- `metricas.csv` / `metricas.md` — tabla de valores de interés.
- `series.csv` — todas las series numéricas alineadas por índice.
- `config.json` — parámetros exactos con los que se corrió.
- `ficha_actividad.md` — objetivo, pasos, verificaciones y preguntas.
- `graficos/*.png` y `graficos/*.svg` — todas las figuras en ambos formatos.
