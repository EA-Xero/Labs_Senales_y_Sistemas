| Métrica | Valor |
|---|---|
| experimento | filtrado_armonico |
| senal | cuadrada |
| sistema | pasaaltos_1 |
| H_de_s | H(s) = [0.2·s] / [0.2·s + 1] |
| formula | H(s) = K·τ·s / (τ·s + 1) |
| f0_hz | 1.0 |
| n_armonicos | 21 |
| fs | 2000.0 |
| ancho_banda_3db_hz | 0.0 |
| armonicos_atenuados_mas_3db | 0 |
| thd_entrada_por_ciento | 45.934402866286476 |
| thd_salida_por_ciento | 57.47475745896785 |
| error_rms_prediccion | 0.13129055199116313 |
| error_rms_relativo | 0.07112259758706256 |
| error_max_relativo | 0.5415747936899192 |
| ganancia_dc | 0.0 |
| verificacion_superposicion_armonica | False |
| verificacion_sistema_no_crea_armonicos | False |
| Señal de entrada | cuadrada |
| Sistema | pasaaltos_1 · H(s) = K·τ·s / (τ·s + 1) |
| f₀ [Hz] | 1.0 |
| Armónicos considerados | 21 |
| Ancho de banda −3 dB [Hz] | 0.0 |
| Armónicos atenuados más de 3 dB | 0 |
| THD de la entrada [%] | 45.934 |
| THD de la salida [%] | 57.475 |
| Error RMS relativo predicción vs simulación | 0.071123 |
| Error máximo relativo | 0.541575 |
