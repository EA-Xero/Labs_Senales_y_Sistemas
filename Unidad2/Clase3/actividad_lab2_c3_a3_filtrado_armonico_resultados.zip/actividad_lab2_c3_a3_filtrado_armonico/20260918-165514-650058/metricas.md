| Métrica | Valor |
|---|---|
| experimento | filtrado_armonico |
| senal | cuadrada |
| sistema | primer_orden |
| H_de_s | H(s) = [1] / [0.2·s + 1] |
| formula | H(s) = K / (τ·s + 1) |
| f0_hz | 1.0 |
| n_armonicos | 21 |
| fs | 2000.0 |
| ancho_banda_3db_hz | 0.796986060182772 |
| armonicos_atenuados_mas_3db | 21 |
| thd_entrada_por_ciento | 45.934402866286476 |
| thd_salida_por_ciento | 15.015384362868108 |
| error_rms_prediccion | 0.0027454063099404615 |
| error_rms_relativo | 0.0032371492301186927 |
| error_max_relativo | 0.025691809664883058 |
| ganancia_dc | 1.0 |
| verificacion_superposicion_armonica | True |
| verificacion_sistema_no_crea_armonicos | True |
| Señal de entrada | cuadrada |
| Sistema | primer_orden · H(s) = K / (τ·s + 1) |
| f₀ [Hz] | 1.0 |
| Armónicos considerados | 21 |
| Ancho de banda −3 dB [Hz] | 0.797 |
| Armónicos atenuados más de 3 dB | 21 |
| THD de la entrada [%] | 45.934 |
| THD de la salida [%] | 15.015 |
| Error RMS relativo predicción vs simulación | 0.003237 |
| Error máximo relativo | 0.025692 |
