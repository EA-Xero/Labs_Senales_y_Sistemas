# Actividad guiada: A3 · Filtrar una señal periódica armónico por armónico
Laboratorio 2 · Unidad 2 · Clase 3 (Series de Fourier y respuesta en frecuencia)
#### A3 · Filtrar una señal periódica armónico por armónico  ·  25 min
*Experimento:* `filtrado_armonico`

**Objetivo.** Unir las dos mitades del laboratorio: predecir la salida con c_k·H(jkω₀) y validarla contra la simulación temporal del sistema.

**Procedimiento**

1. Lanza la corrida principal (cuadrada por un pasa-bajo de primer orden).
2. Compara la salida predicha por Fourier con la simulada: anota el error RMS relativo en régimen permanente.
3. Identifica qué armónicos quedaron por encima del ancho de banda de −3 dB.
4. Compara la THD de entrada y de salida y explica el «redondeo» de los flancos.
5. Repite con el sistema de segundo orden poco amortiguado: observa el armónico realzado por la resonancia.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Error RMS relativo entre predicción y simulación ≤ tolerancia | Figura entrada/salida + tabla CSV |
| El sistema no crea armónicos nuevos (THD salida ≤ THD entrada en pasa-bajo) | Tabla CSV de THD |
| Los armónimos con kf₀ > f_−3dB aparecen atenuados >3 dB | Gráfico de ganancia por armónico |

**Preguntas de análisis (van al informe)**

- ¿Por qué el filtro pasa-bajo redondea los flancos de la onda cuadrada?
- ¿Qué ocurre con el armónico más cercano a la resonancia y por qué?
- ¿De qué orden es la diferencia entre predicción y simulación, y a qué la atribuye?
