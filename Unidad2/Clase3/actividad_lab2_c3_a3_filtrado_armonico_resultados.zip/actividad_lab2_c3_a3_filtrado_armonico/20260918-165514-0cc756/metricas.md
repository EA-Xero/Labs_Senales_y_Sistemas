| Métrica | Valor |
|---|---|
| experimento | filtrado_armonico |
| senal | diente_sierra |
| sistema | pasabanda |
| H_de_s | H(s) = [12·s] / [1·s^2 + 12·s + 144] |
| formula | H(s) = K·2ζωₙ·s / (s² + 2ζωₙ·s + ωₙ²) |
| f0_hz | 1.0 |
| n_armonicos | 21 |
| fs | 2000.0 |
| ancho_banda_3db_hz | 0.0 |
| armonicos_atenuados_mas_3db | 0 |
| thd_entrada_por_ciento | 77.35934178174145 |
| thd_salida_por_ciento | 99.48585140234194 |
| error_rms_prediccion | 0.005084267189933818 |
| error_rms_relativo | 0.00550785223172905 |
| error_max_relativo | 0.05820533988618185 |
| ganancia_dc | 0.0 |
| verificacion_superposicion_armonica | True |
| verificacion_sistema_no_crea_armonicos | False |
| Señal de entrada | diente_sierra |
| Sistema | pasabanda · H(s) = K·2ζωₙ·s / (s² + 2ζωₙ·s + ωₙ²) |
| f₀ [Hz] | 1.0 |
| Armónicos considerados | 21 |
| Ancho de banda −3 dB [Hz] | 0.0 |
| Armónicos atenuados más de 3 dB | 0 |
| THD de la entrada [%] | 77.359 |
| THD de la salida [%] | 99.486 |
| Error RMS relativo predicción vs simulación | 0.005508 |
| Error máximo relativo | 0.058205 |
