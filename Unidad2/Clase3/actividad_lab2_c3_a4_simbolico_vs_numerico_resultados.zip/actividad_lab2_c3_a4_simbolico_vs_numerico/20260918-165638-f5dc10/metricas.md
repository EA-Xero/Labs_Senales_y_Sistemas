| Métrica | Valor |
|---|---|
| experimento | analisis_simbolico |
| sistema | segundo_orden |
| formula | H(s) = K·ωₙ² / (s² + 2ζωₙ·s + ωₙ²) |
| zeta | 0.5 |
| wn | 4.0 |
| tau | 0.5 |
| ganancia | 1.0 |
| cero | 2.0 |
| orden | 2 |
| H_de_s | 16/(s**2 + 4*s + 16) |
| numerador | 16 |
| denominador | s**2 + 4*s + 16 |
| polos_simbolicos | -2 - 2*sqrt(3)*I, -2 + 2*sqrt(3)*I |
| ceros_simbolicos | — |
| fracciones_parciales | 16/(s**2 + 4*s + 16) |
| h_de_t | 8*sqrt(3)*exp(-2*t)*sin(2*sqrt(3)*t)/3 |
| s_de_t | 1 - sqrt(3)*exp(-2*t)*sin(2*sqrt(3)*t)/3 - exp(-2*t)*cos(2*sqrt(3)*t) |
| metodo_inversion | sympy.inverse_laplace_transform |
| edo_equivalente | 1·y^(2) + 4·y' + 16·y = 16·x |
| solucion_edo | 1 - 2*sqrt(3)*exp(-2*t)*sin(2*sqrt(3)*t + pi/3)/3 |
| estable | True |
| ganancia_dc | 1.0 |
| valor_final_simbolico | 1.0 |
| valor_final_numerico | 0.999719089819906 |
| error_max_h | 6.439293542825908e-15 |
| error_max_s | 2.7755575615628914e-15 |
| error_relativo_h | 2.9468139889802394e-15 |
| error_relativo_s | 2.3864820740694404e-15 |
| n_muestras | 3200 |
| Sistema | segundo_orden |
| H(s) | 16/(s**2 + 4*s + 16) |
| Polos simbólicos | -2 - 2*sqrt(3)*I, -2 + 2*sqrt(3)*I |
| Ceros simbólicos | — |
| Fracciones parciales | 16/(s**2 + 4*s + 16) |
| h(t) = ℒ⁻¹{H(s)} | 8*sqrt(3)*exp(-2*t)*sin(2*sqrt(3)*t)/3 |
| s(t) = ℒ⁻¹{H(s)/s} | 1 - sqrt(3)*exp(-2*t)*sin(2*sqrt(3)*t)/3 - exp(-2*t)*cos(2*sqrt(3)*t) |
| Método de inversión | sympy.inverse_laplace_transform |
| EDO equivalente | 1·y^(2) + 4·y' + 16·y = 16·x |
| Solución de la EDO (dsolve) | 1 - 2*sqrt(3)*exp(-2*t)*sin(2*sqrt(3)*t + pi/3)/3 |
| Valor final simbólico | 1.0 |
| Valor final numérico | 0.999719 |
| Error relativo máx. en h(t) | 0.0 |
| Error relativo máx. en s(t) | 0.0 |
