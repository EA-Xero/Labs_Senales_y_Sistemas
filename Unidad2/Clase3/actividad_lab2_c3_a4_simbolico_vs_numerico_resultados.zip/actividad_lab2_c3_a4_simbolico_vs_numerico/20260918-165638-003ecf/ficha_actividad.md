# Actividad guiada: A4 · Análisis simbólico exacto frente al numérico
Laboratorio 2 · Unidad 2 · Clase 3 (Series de Fourier y respuesta en frecuencia)
#### A4 · Análisis simbólico exacto frente al numérico  ·  15 min
*Experimento:* `analisis_simbolico`

**Objetivo.** Obtener H(s), sus fracciones parciales y la transformada inversa exacta, y cuantificar la diferencia con la solución numérica.

**Procedimiento**

1. Lanza la actividad y revisa los pasos simbólicos en la vista en vivo.
2. Anota los polos exactos y compáralos con los numéricos.
3. Reporta el error RMS o máximo entre ambas rutas y explica su origen.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Los polos simbólicos coinciden con las raíces numéricas del denominador | Tabla CSV de polos |
| La diferencia simbólico/numérico está en el orden del error de discretización | Tabla CSV + figura comparativa |

**Preguntas de análisis (van al informe)**

- ¿La discrepancia se reduce al subir fs? ¿Qué indica eso?
- ¿Cuándo conviene la ruta simbólica y cuándo la numérica?
