| Métrica | Valor |
|---|---|
| experimento | analisis_simbolico |
| sistema | primer_orden |
| formula | H(s) = K / (τ·s + 1) |
| zeta | 0.5 |
| wn | 4.0 |
| tau | 0.5 |
| ganancia | 1.0 |
| cero | 2.0 |
| orden | 1 |
| H_de_s | 2/(s + 2) |
| numerador | 1 |
| denominador | s/2 + 1 |
| polos_simbolicos | -2 |
| ceros_simbolicos | — |
| fracciones_parciales | 2/(s + 2) |
| h_de_t | 2*exp(-2*t) |
| s_de_t | 1 - exp(-2*t) |
| metodo_inversion | sympy.inverse_laplace_transform |
| edo_equivalente | 0.5·y' + 1·y = 1·x |
| solucion_edo | 1 - exp(-2*t) |
| estable | True |
| ganancia_dc | 1.0 |
| valor_final_simbolico | 1.0 |
| valor_final_numerico | 0.9996611659166363 |
| error_max_h | 4.107825191113079e-15 |
| error_max_s | 1.1102230246251565e-15 |
| error_relativo_h | 2.0539125955565396e-15 |
| error_relativo_s | 1.1105993335323182e-15 |
| n_muestras | 800 |
| Sistema | primer_orden |
| H(s) | 2/(s + 2) |
| Polos simbólicos | -2 |
| Ceros simbólicos | — |
| Fracciones parciales | 2/(s + 2) |
| h(t) = ℒ⁻¹{H(s)} | 2*exp(-2*t) |
| s(t) = ℒ⁻¹{H(s)/s} | 1 - exp(-2*t) |
| Método de inversión | sympy.inverse_laplace_transform |
| EDO equivalente | 0.5·y' + 1·y = 1·x |
| Solución de la EDO (dsolve) | 1 - exp(-2*t) |
| Valor final simbólico | 1.0 |
| Valor final numérico | 0.999661 |
| Error relativo máx. en h(t) | 0.0 |
| Error relativo máx. en s(t) | 0.0 |
