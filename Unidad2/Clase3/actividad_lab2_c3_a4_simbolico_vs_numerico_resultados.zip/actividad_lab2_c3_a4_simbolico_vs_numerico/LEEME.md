# Bundle de resultados — simulador CIT2410

Evidencia exportada por el simulador para el informe de laboratorio.
Todos los valores provienen de la simulación ejecutada (cálculo real);
no hay datos precomputados.

| Corrida | Experimento | Actividad | Gráficos (PNG+SVG) |
|---|---|---|---|
| `20260918-165638-f5dc10` | analisis_simbolico | A4 · Análisis simbólico exacto frente al numérico | 2 |
| `20260918-165638-35968f` | analisis_simbolico | A4 · Análisis simbólico exacto frente al numérico | 2 |
| `20260918-165638-003ecf` | analisis_simbolico | A4 · Análisis simbólico exacto frente al numérico | 2 |

## Contenido por corrida

- `resultado.json` — resultado completo (métricas y series).
- `metricas.csv` / `metricas.md` — tabla de valores de interés.
- `series.csv` — todas las series numéricas alineadas por índice.
- `config.json` — parámetros exactos con los que se corrió.
- `ficha_actividad.md` — objetivo, pasos, verificaciones y preguntas.
- `graficos/*.png` y `graficos/*.svg` — todas las figuras en ambos formatos.
