| Métrica | Valor |
|---|---|
| experimento | propiedades_convolucion |
| tipo_x | rectangular |
| tipo_h | exponencial_decreciente |
| tipo_g | triangular |
| fs | 500.0 |
| duracion_observada | 6.0 |
| error_rms_definicion_vs_rutina | 0.0 |
| error_rms_relativo | 0.0 |
| error_conmutatividad | 7.537179160127104e-16 |
| error_asociatividad | 2.5471096987968887e-15 |
| error_distributividad | 5.86128607400487e-16 |
| soporte_x_s | 1.0 |
| soporte_h_s | 3.684 |
| soporte_y_medido_s | 4.684 |
| soporte_y_esperado_s | 4.684 |
| error_relativo_soporte | 0.0 |
| area_x | 1.002 |
| area_h | 0.40100071066590065 |
| area_y_medida | 0.4018027120872326 |
| area_y_esperada | 0.40180271208723245 |
| error_relativo_area | 4.1446572828910776e-16 |
| ventana_truncada | False |
| verificacion_conmutativa | True |
| verificacion_asociativa | True |
| verificacion_distributiva | True |
| verificacion_regla_soporte | True |
| verificacion_identidad_areas | True |
| Error RMS definición vs rutina | 0.0 |
| Error conmutatividad | 0.0 |
| Error asociatividad | 0.0 |
| Error distributividad | 0.0 |
| T_x [s] | 1.0 |
| T_h [s] | 3.684 |
| T_y medida [s] | 4.684 |
| T_x + T_h [s] | 4.684 |
| ∫y medida | 0.401803 |
| ∫x·∫h esperada | 0.401803 |
| ¿Ventana truncada? | False |
