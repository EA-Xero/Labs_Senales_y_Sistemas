# Actividad guiada: A2 · Propiedades de la convolución y las dos reglas de oro
Laboratorio 2 · Unidad 2 · Clase 1 (Sistemas LTI y convolución)
#### A2 · Propiedades de la convolución y las dos reglas de oro  ·  20 min
*Experimento:* `propiedades_convolucion`

**Objetivo.** Verificar conmutatividad, asociatividad y distributividad, y usar la regla del soporte y la del área como control de calidad de cualquier convolución del informe.

**Procedimiento**

1. Lanza la actividad y revisa los cinco cuadros de la vista en vivo.
2. Compara la suma por definición con la rutina optimizada: anota el error RMS.
3. Comprueba ∫y = ∫x·∫h y explica el papel del factor dt.
4. Repite con la variante de ventana corta y observa el campo «ventana_truncada».

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Errores de conmutatividad, asociatividad y distributividad ≤ tolerancia | Tabla CSV de errores |
| T_y medida = T_x + T_h (error relativo pequeño) | Tabla CSV |
| ∫y = ∫x·∫h (error relativo ≤ tolerancia) | Tabla CSV de áreas |

**Preguntas de análisis (van al informe)**

- ¿Qué error introduce la discretización en la identidad de áreas?
- ¿Cómo detectaría, sólo con el área, un error de escala en dt?
