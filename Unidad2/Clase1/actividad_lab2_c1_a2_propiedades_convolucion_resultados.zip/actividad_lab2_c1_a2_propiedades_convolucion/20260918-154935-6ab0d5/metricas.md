| Métrica | Valor |
|---|---|
| experimento | propiedades_convolucion |
| tipo_x | gaussiana |
| tipo_h | rampa_finita |
| tipo_g | triangular |
| fs | 500.0 |
| duracion_observada | 6.0 |
| error_rms_definicion_vs_rutina | 5.3671998585164e-18 |
| error_rms_relativo | 2.0587248046451725e-17 |
| error_conmutatividad | 1.9163431265481286e-15 |
| error_asociatividad | 2.07475044493663e-15 |
| error_distributividad | 1.7225589281567353e-15 |
| soporte_x_s | 2.072 |
| soporte_h_s | 0.598 |
| soporte_y_medido_s | 2.4019999999999997 |
| soporte_y_esperado_s | 2.67 |
| error_relativo_soporte | 0.10037453183520609 |
| area_x | 0.626637555323701 |
| area_h | 0.30100000000000005 |
| area_y_medida | 0.18861790415243398 |
| area_y_esperada | 0.18861790415243404 |
| error_relativo_area | 2.9430478236252565e-16 |
| ventana_truncada | False |
| verificacion_conmutativa | True |
| verificacion_asociativa | True |
| verificacion_distributiva | True |
| verificacion_regla_soporte | False |
| verificacion_identidad_areas | True |
| Error RMS definición vs rutina | 0.0 |
| Error conmutatividad | 0.0 |
| Error asociatividad | 0.0 |
| Error distributividad | 0.0 |
| T_x [s] | 2.072 |
| T_h [s] | 0.598 |
| T_y medida [s] | 2.402 |
| T_x + T_h [s] | 2.67 |
| ∫y medida | 0.188618 |
| ∫x·∫h esperada | 0.188618 |
| ¿Ventana truncada? | False |
