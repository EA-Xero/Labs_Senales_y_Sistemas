# Bundle de resultados — simulador CIT2410

Evidencia exportada por el simulador para el informe de laboratorio.
Todos los valores provienen de la simulación ejecutada (cálculo real);
no hay datos precomputados.

| Corrida | Experimento | Actividad | Gráficos (PNG+SVG) |
|---|---|---|---|
| `20260918-154935-b03bc2` | propiedades_convolucion | A2 · Propiedades de la convolución y las dos reglas de oro | 2 |
| `20260918-154935-9df753` | propiedades_convolucion | A2 · Propiedades de la convolución y las dos reglas de oro | 2 |
| `20260918-154935-6ab0d5` | propiedades_convolucion | A2 · Propiedades de la convolución y las dos reglas de oro | 2 |

## Contenido por corrida

- `resultado.json` — resultado completo (métricas y series).
- `metricas.csv` / `metricas.md` — tabla de valores de interés.
- `series.csv` — todas las series numéricas alineadas por índice.
- `config.json` — parámetros exactos con los que se corrió.
- `ficha_actividad.md` — objetivo, pasos, verificaciones y preguntas.
- `graficos/*.png` y `graficos/*.svg` — todas las figuras en ambos formatos.
