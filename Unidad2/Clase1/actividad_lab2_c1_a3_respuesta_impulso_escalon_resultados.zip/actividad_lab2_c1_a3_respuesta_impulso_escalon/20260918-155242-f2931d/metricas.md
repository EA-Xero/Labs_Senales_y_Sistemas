| Métrica | Valor |
|---|---|
| experimento | respuesta_impulso_escalon |
| sistema | segundo_orden |
| formula | H(s) = K·ωₙ² / (s² + 2ζωₙ·s + ωₙ²) |
| transferencia | H(s) = [16] / [1·s^2 + 0.8·s + 16] |
| entrada | escalon |
| ganancia | 1.0 |
| tau | 0.5 |
| wn | 4.0 |
| zeta | 0.1 |
| cero | 1.0 |
| fs | 400.0 |
| duracion | 5.0 |
| n_muestras | 2000 |
| estable | True |
| ganancia_dc | 1.0 |
| valor_final_medido | 0.9197067995167632 |
| valor_final_teorico | 1.0 |
| sobreimpulso_pct | 88.02135500535267 |
| sobreimpulso_teorico_pct | 72.9247614287671 |
| t_pico_s | 0.79 |
| t_subida_10_90_s | 0.26 |
| t_asentamiento_2pct_s | 4.955 |
| error_integral_h_vs_s | 0.00430464609290182 |
| error_relativo_convolucion | 0.002489320847292889 |
| energia_h | 9.79789460668351 |
| max_h | 3.450394836125082 |
| Sistema | segundo_orden |
| H(s) | H(s) = [16] / [1·s^2 + 0.8·s + 16] |
| ¿Estable? | sí |
| Ganancia DC H(0) | 1.0 |
| Valor final medido | 0.919707 |
| Sobreimpulso [%] | 88.0214 |
| Sobreimpulso teórico [%] | 72.9248 |
| Tiempo de pico [s] | 0.79 |
| Tiempo de subida 10–90 % [s] | 0.26 |
| Tiempo de asentamiento 2 % [s] | 4.955 |
| Error máx. |∫h − s| | 0.00430465 |
| Error relativo |lsim − x∗h| | 0.00248932 |
