# Bundle de resultados — simulador CIT2410

Evidencia exportada por el simulador para el informe de laboratorio.
Todos los valores provienen de la simulación ejecutada (cálculo real);
no hay datos precomputados.

| Corrida | Experimento | Actividad | Gráficos (PNG+SVG) |
|---|---|---|---|
| `20260918-155242-fc918c` | respuesta_impulso_escalon | A3 · Respuesta al impulso y al escalón: métricas del transitorio | 3 |
| `20260918-155242-f2931d` | respuesta_impulso_escalon | A3 · Respuesta al impulso y al escalón: métricas del transitorio | 3 |
| `20260918-155242-b683fc` | respuesta_impulso_escalon | A3 · Respuesta al impulso y al escalón: métricas del transitorio | 3 |
| `20260918-155242-661f13` | respuesta_impulso_escalon | A3 · Respuesta al impulso y al escalón: métricas del transitorio | 3 |

## Contenido por corrida

- `resultado.json` — resultado completo (métricas y series).
- `metricas.csv` / `metricas.md` — tabla de valores de interés.
- `series.csv` — todas las series numéricas alineadas por índice.
- `config.json` — parámetros exactos con los que se corrió.
- `ficha_actividad.md` — objetivo, pasos, verificaciones y preguntas.
- `graficos/*.png` y `graficos/*.svg` — todas las figuras en ambos formatos.
