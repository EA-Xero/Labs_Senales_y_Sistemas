# Actividad guiada: A3 · Respuesta al impulso y al escalón: métricas del transitorio
Laboratorio 2 · Unidad 2 · Clase 1 (Sistemas LTI y convolución)
#### A3 · Respuesta al impulso y al escalón: métricas del transitorio  ·  20 min
*Experimento:* `respuesta_impulso_escalon`

**Objetivo.** Medir tiempo de subida, asentamiento, sobreimpulso y valor final, y comprobar que ∫h = s y que la salida de lsim coincide con x*h.

**Procedimiento**

1. Lanza la corrida con el sistema de segundo orden.
2. Anota las métricas del transitorio y relaciónalas con ζ y ωₙ.
3. Repite con las variantes (primer orden y ζ pequeño) y compara.
4. Verifica en h(t) la causalidad (nula para t<0) y la estabilidad.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| s(t) coincide con la integral acumulada de h(t) | Figura h(t) y s(t) |
| Valor final de s(t) = ganancia DC del sistema | Tabla CSV |
| Sobreimpulso crece al reducir ζ | resumen_corridas.csv de la actividad |

**Preguntas de análisis (van al informe)**

- ¿Qué relación observó entre ζ y el sobreimpulso medido?
- ¿Cómo se lee la estabilidad BIBO directamente en h(t)?
