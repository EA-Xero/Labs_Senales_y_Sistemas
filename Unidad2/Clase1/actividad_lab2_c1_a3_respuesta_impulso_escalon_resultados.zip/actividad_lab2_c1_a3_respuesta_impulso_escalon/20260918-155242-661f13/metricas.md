| Métrica | Valor |
|---|---|
| experimento | respuesta_impulso_escalon |
| sistema | segundo_orden |
| formula | H(s) = K·ωₙ² / (s² + 2ζωₙ·s + ωₙ²) |
| transferencia | H(s) = [16] / [1·s^2 + 3.2·s + 16] |
| entrada | senoidal |
| ganancia | 1.0 |
| tau | 0.5 |
| wn | 4.0 |
| zeta | 0.4 |
| cero | 1.0 |
| fs | 400.0 |
| duracion | 5.0 |
| n_muestras | 2000 |
| estable | True |
| ganancia_dc | 1.0 |
| valor_final_medido | 0.9997832414700097 |
| valor_final_teorico | 1.0 |
| sobreimpulso_pct | 25.409792118882784 |
| sobreimpulso_teorico_pct | 25.38267219801087 |
| t_pico_s | 0.8575 |
| t_subida_10_90_s | 0.365 |
| t_asentamiento_2pct_s | 2.1 |
| error_integral_h_vs_s | 0.0030063147390322342 |
| error_relativo_convolucion | 5.831634534017535e-05 |
| energia_h | 2.4999997971375656 |
| max_h | 2.411698823228952 |
| Sistema | segundo_orden |
| H(s) | H(s) = [16] / [1·s^2 + 3.2·s + 16] |
| ¿Estable? | sí |
| Ganancia DC H(0) | 1.0 |
| Valor final medido | 0.999783 |
| Sobreimpulso [%] | 25.4098 |
| Sobreimpulso teórico [%] | 25.3827 |
| Tiempo de pico [s] | 0.8575 |
| Tiempo de subida 10–90 % [s] | 0.365 |
| Tiempo de asentamiento 2 % [s] | 2.1 |
| Error máx. |∫h − s| | 0.00300631 |
| Error relativo |lsim − x∗h| | 5.832e-05 |
