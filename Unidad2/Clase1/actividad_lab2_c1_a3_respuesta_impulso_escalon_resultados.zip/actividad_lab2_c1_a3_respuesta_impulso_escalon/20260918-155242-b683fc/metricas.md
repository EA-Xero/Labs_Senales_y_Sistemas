| Métrica | Valor |
|---|---|
| experimento | respuesta_impulso_escalon |
| sistema | primer_orden |
| formula | H(s) = K / (τ·s + 1) |
| transferencia | H(s) = [1] / [0.5·s + 1] |
| entrada | escalon |
| ganancia | 1.0 |
| tau | 0.5 |
| wn | 4.0 |
| zeta | 0.4 |
| cero | 1.0 |
| fs | 400.0 |
| duracion | 5.0 |
| n_muestras | 2000 |
| estable | True |
| ganancia_dc | 1.0 |
| valor_final_medido | 0.9999543725021418 |
| valor_final_teorico | 1.0 |
| sobreimpulso_pct | 0.0 |
| sobreimpulso_teorico_pct | 0.0 |
| t_pico_s | 4.9975 |
| t_subida_10_90_s | 1.0975000000000001 |
| t_asentamiento_2pct_s | 1.9525 |
| error_integral_h_vs_s | 0.005 |
| error_relativo_convolucion | 0.0050002281478991085 |
| energia_h | 1.00500833124797 |
| max_h | 2.0 |
| Sistema | primer_orden |
| H(s) | H(s) = [1] / [0.5·s + 1] |
| ¿Estable? | sí |
| Ganancia DC H(0) | 1.0 |
| Valor final medido | 0.999954 |
| Sobreimpulso [%] | 0.0 |
| Sobreimpulso teórico [%] | 0.0 |
| Tiempo de pico [s] | 4.9975 |
| Tiempo de subida 10–90 % [s] | 1.0975 |
| Tiempo de asentamiento 2 % [s] | 1.9525 |
| Error máx. |∫h − s| | 0.005 |
| Error relativo |lsim − x∗h| | 0.00500023 |
