# Laboratorio 2 — Sistemas LTI, convolución y respuesta en frecuencia

**Sesiones:** 3 clases de 90 minutos (semanas 5, 9 y 10)

**Informe:** Informe grupal del Laboratorio 2 (cubre las tres clases)

## Objetivos del laboratorio

1. Calcular la salida de un sistema LTI por convolución y entender h(t) como su identificación completa.
2. Analizar sistemas descritos por ecuaciones diferenciales mediante H(s), su Bode y su mapa de polos y ceros.
3. Descomponer señales periódicas en series de Fourier y predecir la salida del sistema armónico por armónico.
4. Contrastar el análisis simbólico exacto con la solución numérica del mismo sistema.

**Resultados de aprendizaje asociados:** RA2 (respuesta a impulso de filtros); RA4 (filtraje); RA6 (informes técnicos)

### Clase 1 — Sistemas LTI y convolución
*Semana 5 · bloque 1 de 3 · 90 minutos*

La respuesta al impulso como **identificación completa** de un sistema LTI: si se conoce h(t), se conoce todo. La convolución se calcula, se verifica con la regla del soporte y del área, y se usa para construir interconexiones.

**Tema de apoyo del calendario:** Sistemas LTI y Convolución

**Objetivos de la clase**

- Calcular la salida de un LTI por convolución y verificarla con dos reglas independientes (soporte y área).
- Comprobar las propiedades algebraicas de la convolución con datos medidos.
- Medir h(t) y s(t) y leer en ellas causalidad y estabilidad.
- Obtener el equivalente de sistemas en serie, en paralelo y en lazo cerrado.

**Plan de los 90 minutos**

| Bloque | min |
|---|---|
| Sistemas LTI: definición y por qué h(t) lo describe todo | 20 |
| La integral de convolución: cuatro pasos y propiedades | 25 |
| Respuesta al impulso y al escalón: métricas del transitorio | 20 |
| Puesta en marcha del simulador y primera convolución animada | 20 |
| Cierre y tareas | 5 |

**Actividades guiadas en el simulador**

#### A1 · Convolución paso a paso  ·  15 min
*Experimento:* `convolucion_animada`

**Objetivo.** Ver los cuatro pasos (reflejar, desplazar, multiplicar, integrar) y comprobar que la duración de la salida es la suma de duraciones.

**Procedimiento**

1. Lanza la actividad y sigue en *Vista en vivo* el deslizamiento de h reflejada sobre x.
2. Anota cuándo empieza y cuándo termina el solape: ahí está el soporte.
3. Repite con la variante triangular–triangular y compara la forma resultante.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| T_y = T_x + T_h en la salida medida | Figura PNG/SVG de y(t) |
| La salida vale cero fuera del intervalo de solape | Tabla CSV de la corrida |

**Preguntas de análisis (van al informe)**

- ¿Por qué la convolución de dos pulsos rectangulares da un trapecio?
- ¿Qué duración de ventana necesitó y cómo la dimensionó?

**Errores frecuentes**

- Ventana demasiado corta: la salida aparece truncada antes de T_x+T_h.

#### A2 · Propiedades de la convolución y las dos reglas de oro  ·  20 min
*Experimento:* `propiedades_convolucion`

**Objetivo.** Verificar conmutatividad, asociatividad y distributividad, y usar la regla del soporte y la del área como control de calidad de cualquier convolución del informe.

**Procedimiento**

1. Lanza la actividad y revisa los cinco cuadros de la vista en vivo.
2. Compara la suma por definición con la rutina optimizada: anota el error RMS.
3. Comprueba ∫y = ∫x·∫h y explica el papel del factor dt.
4. Repite con la variante de ventana corta y observa el campo «ventana_truncada».

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Errores de conmutatividad, asociatividad y distributividad ≤ tolerancia | Tabla CSV de errores |
| T_y medida = T_x + T_h (error relativo pequeño) | Tabla CSV |
| ∫y = ∫x·∫h (error relativo ≤ tolerancia) | Tabla CSV de áreas |

**Preguntas de análisis (van al informe)**

- ¿Qué error introduce la discretización en la identidad de áreas?
- ¿Cómo detectaría, sólo con el área, un error de escala en dt?

#### A3 · Respuesta al impulso y al escalón: métricas del transitorio  ·  20 min
*Experimento:* `respuesta_impulso_escalon`

**Objetivo.** Medir tiempo de subida, asentamiento, sobreimpulso y valor final, y comprobar que ∫h = s y que la salida de lsim coincide con x*h.

**Procedimiento**

1. Lanza la corrida con el sistema de segundo orden.
2. Anota las métricas del transitorio y relaciónalas con ζ y ωₙ.
3. Repite con las variantes (primer orden y ζ pequeño) y compara.
4. Verifica en h(t) la causalidad (nula para t<0) y la estabilidad.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| s(t) coincide con la integral acumulada de h(t) | Figura h(t) y s(t) |
| Valor final de s(t) = ganancia DC del sistema | Tabla CSV |
| Sobreimpulso crece al reducir ζ | resumen_corridas.csv de la actividad |

**Preguntas de análisis (van al informe)**

- ¿Qué relación observó entre ζ y el sobreimpulso medido?
- ¿Cómo se lee la estabilidad BIBO directamente en h(t)?

#### A4 · Interconexión: serie, paralelo y realimentación  ·  20 min
*Experimento:* `interconexion_sistemas`

**Objetivo.** Comprobar h_eq = h₁*h₂ en cascada, h_eq = h₁+h₂ en paralelo y ver cómo la realimentación mueve los polos.

**Procedimiento**

1. Lanza la actividad: cubre las tres topologías con los mismos H₁ y H₂.
2. Para la cascada, compara h_eq simulada con la convolución h₁*h₂.
3. Para el lazo cerrado, anota los polos y compáralos con los de H₁.
4. Prueba la variante que realimenta un sistema inestable y observa el cambio de estabilidad.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Error RMS relativo entre h_eq simulada y la predicción ≤ tolerancia | Figura h_eq vs predicción |
| Valor final del escalón = H_eq(0) | Tabla CSV |
| Los polos del lazo cerrado son raíces de d₁d₂ + n₁n₂ | Figura de polos en el plano s |

**Preguntas de análisis (van al informe)**

- ¿Por qué el orden de las etapas en cascada no cambia la salida?
- ¿Qué le pasó a la ganancia DC al cerrar el lazo y por qué?

**Cierre de la clase**

- Cada grupo termina con la convolución verificada por soporte y área, y con las métricas del transitorio exportadas.
- Tarea para la semana 9: repasar series de Fourier (coeficientes y espectro de líneas).

### Clase 2 — Series de Fourier: espectro de líneas, Gibbs y Parseval
*Semana 9 · bloque 2 de 3 · 90 minutos*

De la señal periódica a su espectro de líneas. Los coeficientes se **calculan** por cuadratura sobre un periodo, la serie se reconstruye armónico a armónico y el balance de potencia se cierra con Parseval.

**Tema de apoyo del calendario:** Series de Fourier

**Objetivos de la clase**

- Calcular c_k y comprobar la simetría conjugada del espectro de una señal real.
- Medir el sobreimpulso de Gibbs y su convergencia al 8,95 %.
- Verificar la identidad de Parseval y cuantificar la potencia fuera de N armónicos.
- Ajustar el decaimiento de |c_k| en escala log–log.

**Plan de los 90 minutos**

| Bloque | min |
|---|---|
| De la convolución al análisis en frecuencia: por qué e^{jωt} es la señal de prueba | 10 |
| Serie exponencial y trigonométrica: coeficientes y simetrías | 25 |
| Convergencia, Gibbs y potencia (Parseval) | 20 |
| Desarrollo con los experimentos de series | 30 |
| Síntesis y avance de redacción del informe | 5 |

**Actividades guiadas en el simulador**

#### A1 · Coeficientes, Gibbs, Parseval y decaimiento  ·  25 min
*Experimento:* `serie_fourier_gibbs`

**Objetivo.** Obtener las cinco verificaciones de la sesión sobre una onda cuadrada y contrastarlas con otras formas de onda.

**Procedimiento**

1. Lanza la corrida principal (cuadrada, N = 25) y observa la reconstrucción creciendo armónico a armónico.
2. Compara |c_k| medido con 2A/(πk) para k impar y confirma los ceros en k par.
3. Mira el gráfico de sobreimpulso vs N: debe acercarse al 8,95 % sin bajar.
4. Revisa el balance de potencia: qué fracción queda dentro de N armónicos.
5. Repite con triangular y diente de sierra y compara las pendientes log–log.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| |c_k| = 2A/(πk) en k impar y ≈ 0 en k par (onda cuadrada) | Tabla CSV de coeficientes + espectro de líneas |
| Sobreimpulso → 8,95 % al crecer N | Gráfico sobreimpulso vs N |
| Potencia en el tiempo = Σ|c_k|² (error ≤ tolerancia) | Tabla CSV de balance de potencia |
| c₋ₖ = c*ₖ (error ≈ 0) | Tabla CSV de simetría |
| Pendiente ≈ −1 en log–log de |c_k| (cuadrada) | Gráfico log–log de |c_k| |

**Preguntas de análisis (van al informe)**

- ¿Por qué el sobreimpulso no desaparece al aumentar N?
- ¿Qué diferencia hay entre la pendiente log–log de la cuadrada y la de la triangular, y qué dice sobre la suavidad de la señal?
- ¿Cuántos armónicos necesita para capturar el 99 % de la potencia?

**Errores frecuentes**

- Observar menos de un periodo completo: los coeficientes salen mal.
- Confundir el sobreimpulso de Gibbs con un error del simulador.

#### A2 · ¿Cuántos armónicos hacen falta?  ·  15 min
*Experimento:* `serie_fourier_gibbs`

**Objetivo.** Cuantificar el compromiso entre número de armónicos, error RMS y potencia capturada, para justificar el N usado en el informe.

**Procedimiento**

1. Lanza las tres corridas con N creciente.
2. Tabula error RMS y fracción de potencia frente a N.
3. Elige y justifica el N que usará el grupo en el resto del laboratorio.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| El error RMS decrece monótonamente con N | Gráfico error RMS vs N |
| La fracción de potencia capturada crece y tiende a 1 | Gráfico de potencia acumulada |

**Preguntas de análisis (van al informe)**

- ¿Qué criterio usó para elegir N: error RMS o potencia capturada?

**Cierre de la clase**

- Exportar el bundle de la actividad: trae las corridas de todas las formas de onda con su resumen comparativo.
- Para la semana 10: repasar función de transferencia, Bode y polos/ceros.

### Clase 3 — Series de Fourier y respuesta en frecuencia
*Semana 10 · bloque 3 de 3 · 90 minutos*

Filtrar **armónico por armónico** con H(s): de la ecuación diferencial al diagrama de Bode, del mapa de polos a la respuesta temporal, y del análisis simbólico exacto al numérico.

**Tema de apoyo del calendario:** Series de Fourier

**Objetivos de la clase**

- Obtener H(s) y leer en su Bode la ganancia, el ancho de banda de −3 dB y la resonancia.
- Relacionar la posición de los polos con la forma de la respuesta temporal.
- Predecir la salida de una señal periódica armónico por armónico y validarla contra la simulación temporal.
- Contrastar el análisis simbólico exacto con la solución numérica y cuantificar la diferencia.

**Plan de los 90 minutos**

| Bloque | min |
|---|---|
| De la ecuación diferencial a H(s): polos, ceros y significado | 15 |
| Diagrama de Bode y métricas (−3 dB, resonancia, pendientes asintóticas) | 20 |
| Filtrado de señales periódicas y análisis simbólico vs numérico | 25 |
| Desarrollo con los experimentos de la clase | 25 |
| Cierre del informe y reparto de la redacción | 5 |

**Actividades guiadas en el simulador**

#### A1 · Bode: ganancia, −3 dB y resonancia  ·  15 min
*Experimento:* `bode_transferencia`

**Objetivo.** Medir magnitud y fase de H(jω) y las métricas que definen la velocidad y la resonancia del sistema.

**Procedimiento**

1. Lanza la corrida con el sistema de segundo orden.
2. Anota el ancho de banda de −3 dB y el pico de resonancia.
3. Repite con ζ pequeño y con ganancia ×10: comprueba el desplazamiento de ±20 dB y el crecimiento del pico.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Multiplicar K por 10 desplaza la magnitud +20 dB | resumen_corridas.csv de la actividad |
| El pico de resonancia aparece sólo si ζ < 0,707 | Gráfico de magnitud en dB |

**Preguntas de análisis (van al informe)**

- ¿Qué pendiente asintótica midió y cuántos polos la explican?
- ¿Cómo se relaciona el ancho de banda de −3 dB con el tiempo de subida?

#### A2 · Migración de polos y frontera de estabilidad  ·  15 min
*Experimento:* `mapa_polos_ceros`

**Objetivo.** Ver cómo la posición de los polos determina oscilación, amortiguamiento y estabilidad.

**Procedimiento**

1. Lanza la actividad y observa la migración de los polos en el plano s.
2. Relaciona la parte real con la velocidad de decaimiento e^{σt}.
3. Prueba la variante inestable y describe qué cambia en la respuesta.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Estable ⇔ todos los polos con parte real negativa | Figura del plano s + tabla CSV |
| Polos complejos conjugados ⇒ respuesta oscilatoria amortiguada | Figura de la respuesta temporal |

**Preguntas de análisis (van al informe)**

- ¿Qué polo domina la respuesta y por qué?

#### A3 · Filtrar una señal periódica armónico por armónico  ·  25 min
*Experimento:* `filtrado_armonico`

**Objetivo.** Unir las dos mitades del laboratorio: predecir la salida con c_k·H(jkω₀) y validarla contra la simulación temporal del sistema.

**Procedimiento**

1. Lanza la corrida principal (cuadrada por un pasa-bajo de primer orden).
2. Compara la salida predicha por Fourier con la simulada: anota el error RMS relativo en régimen permanente.
3. Identifica qué armónicos quedaron por encima del ancho de banda de −3 dB.
4. Compara la THD de entrada y de salida y explica el «redondeo» de los flancos.
5. Repite con el sistema de segundo orden poco amortiguado: observa el armónico realzado por la resonancia.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Error RMS relativo entre predicción y simulación ≤ tolerancia | Figura entrada/salida + tabla CSV |
| El sistema no crea armónicos nuevos (THD salida ≤ THD entrada en pasa-bajo) | Tabla CSV de THD |
| Los armónimos con kf₀ > f_−3dB aparecen atenuados >3 dB | Gráfico de ganancia por armónico |

**Preguntas de análisis (van al informe)**

- ¿Por qué el filtro pasa-bajo redondea los flancos de la onda cuadrada?
- ¿Qué ocurre con el armónico más cercano a la resonancia y por qué?
- ¿De qué orden es la diferencia entre predicción y simulación, y a qué la atribuye?

#### A4 · Análisis simbólico exacto frente al numérico  ·  15 min
*Experimento:* `analisis_simbolico`

**Objetivo.** Obtener H(s), sus fracciones parciales y la transformada inversa exacta, y cuantificar la diferencia con la solución numérica.

**Procedimiento**

1. Lanza la actividad y revisa los pasos simbólicos en la vista en vivo.
2. Anota los polos exactos y compáralos con los numéricos.
3. Reporta el error RMS o máximo entre ambas rutas y explica su origen.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Los polos simbólicos coinciden con las raíces numéricas del denominador | Tabla CSV de polos |
| La diferencia simbólico/numérico está en el orden del error de discretización | Tabla CSV + figura comparativa |

**Preguntas de análisis (van al informe)**

- ¿La discrepancia se reduce al subir fs? ¿Qué indica eso?
- ¿Cuándo conviene la ruta simbólica y cuándo la numérica?

**Cierre de la clase**

- Descargar el **bundle ZIP de la sesión completa** con las tres clases.
- Estructura del informe: convolución y h(t), serie de Fourier de la señal elegida, respuesta en frecuencia y filtrado, contraste simbólico/numérico.

## Estructura sugerida del informe

1. Convolución y respuesta al impulso: verificaciones de soporte y área.
2. Serie de Fourier de la señal elegida: coeficientes, Gibbs y Parseval.
3. Respuesta en frecuencia: Bode, polos/ceros y filtrado armónico.
4. Contraste simbólico/numérico con su error cuantificado.
5. Conclusiones y anexo con el bundle ZIP de la sesión completa.
