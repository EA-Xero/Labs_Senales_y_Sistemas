# Bundle de resultados — simulador CIT2410

Evidencia exportada por el simulador para el informe de laboratorio.
Todos los valores provienen de la simulación ejecutada (cálculo real);
no hay datos precomputados.

| Corrida | Experimento | Actividad | Gráficos (PNG+SVG) |
|---|---|---|---|
| `20260918-155530-fca987` | interconexion_sistemas | A4 · Interconexión: serie, paralelo y realimentación | 4 |
| `20260918-155530-991ee3` | interconexion_sistemas | A4 · Interconexión: serie, paralelo y realimentación | 4 |
| `20260918-155530-955bde` | interconexion_sistemas | A4 · Interconexión: serie, paralelo y realimentación | 4 |
| `20260918-155530-90e283` | interconexion_sistemas | A4 · Interconexión: serie, paralelo y realimentación | 4 |
| `20260918-155242-fc918c` | respuesta_impulso_escalon | A3 · Respuesta al impulso y al escalón: métricas del transitorio | 3 |
| `20260918-155242-f2931d` | respuesta_impulso_escalon | A3 · Respuesta al impulso y al escalón: métricas del transitorio | 3 |
| `20260918-155242-b683fc` | respuesta_impulso_escalon | A3 · Respuesta al impulso y al escalón: métricas del transitorio | 3 |
| `20260918-155242-661f13` | respuesta_impulso_escalon | A3 · Respuesta al impulso y al escalón: métricas del transitorio | 3 |
| `20260918-154935-b03bc2` | propiedades_convolucion | A2 · Propiedades de la convolución y las dos reglas de oro | 2 |
| `20260918-154935-9df753` | propiedades_convolucion | A2 · Propiedades de la convolución y las dos reglas de oro | 2 |
| `20260918-154935-6ab0d5` | propiedades_convolucion | A2 · Propiedades de la convolución y las dos reglas de oro | 2 |
| `20260918-152341-cd7d45` | convolucion_animada | A1 · Convolución paso a paso | 4 |
| `20260918-152341-b778f3` | convolucion_animada | A1 · Convolución paso a paso | 4 |
| `20260918-152341-0007d4` | convolucion_animada | A1 · Convolución paso a paso | 4 |

## Contenido por corrida

- `resultado.json` — resultado completo (métricas y series).
- `metricas.csv` / `metricas.md` — tabla de valores de interés.
- `series.csv` — todas las series numéricas alineadas por índice.
- `config.json` — parámetros exactos con los que se corrió.
- `ficha_actividad.md` — objetivo, pasos, verificaciones y preguntas.
- `graficos/*.png` y `graficos/*.svg` — todas las figuras en ambos formatos.
