| Métrica | Valor |
|---|---|
| experimento | interconexion_sistemas |
| topologia | realimentacion_negativa |
| sistema1 | primer_orden |
| sistema2 | primer_orden |
| H1 | H(s) = [1] / [0.5·s + 1] |
| H2 | H(s) = [1] / [0.2·s + 1] |
| H_equivalente | H(s) = [0.2·s + 1] / [0.1·s^2 + 0.7·s + 2] |
| fs | 500.0 |
| duracion_observada | 5.0 |
| error_rms_relativo_prediccion | 0.0 |
| ganancia_dc_algebraica | 0.5 |
| valor_final_escalon_medido | 0.49999999941427775 |
| error_relativo_ganancia_dc | 1.1714444969612714e-09 |
| n_polos_equivalente | 2 |
| parte_real_maxima_polos | -3.499999999999999 |
| equivalente_estable | True |
| verificacion_h_equivalente | True |
| verificacion_ganancia_dc | True |
| Topología | realimentacion_negativa |
| H₁ | H(s) = [1] / [0.5·s + 1] |
| H₂ | H(s) = [1] / [0.2·s + 1] |
| H equivalente | H(s) = [0.2·s + 1] / [0.1·s^2 + 0.7·s + 2] |
| Error RMS relativo vs predicción | 0.0 |
| Ganancia DC algebraica | 0.5 |
| Valor final medido del escalón | 0.5 |
| Nº de polos del equivalente | 2 |
| Parte real máxima de los polos | -3.5 |
| ¿Equivalente BIBO estable? | True |
