| Métrica | Valor |
|---|---|
| experimento | convolucion_animada |
| tipo_x | rectangular |
| tipo_h | exponencial_decreciente |
| amplitud_x | 1.0 |
| amplitud_h | 1.0 |
| ancho_x | 1.0 |
| ancho_h | 0.6 |
| fs | 200.0 |
| n_muestras_x | 201 |
| n_muestras_h | 121 |
| n_muestras_y | 321 |
| area_x | 1.0050000000000001 |
| area_h | 0.19267695194561485 |
| area_y | 0.19364033670534295 |
| area_y_teorica | 0.19364033670534295 |
| error_relativo_area | 0.0 |
| error_conmutatividad | 0.0 |
| energia_x | 1.0050000000000001 |
| energia_h | 0.10227910248958572 |
| energia_y | 0.03153769640857601 |
| max_y | 0.1926769519456149 |
| t_max_y_s | 0.6 |
| duracion_y_s | 1.6 |
| duracion_y_teorica_s | 1.6 |
| t_instantanea_s | 0.81 |
| Entrada x(t) | rectangular |
| Respuesta al impulso h(t) | exponencial_decreciente |
| ∫x dt | 1.005 |
| ∫h dt | 0.192677 |
| ∫y dt (medida) | 0.19364 |
| (∫x)·(∫h) (teórica) | 0.19364 |
| Error relativo de área | 0.0 |
| Error de conmutatividad |x∗h − h∗x| | 0.0 |
| Máximo de y(t) | 0.192677 |
| Instante del máximo [s] | 0.6 |
| Duración del soporte de y [s] | 1.6 |
