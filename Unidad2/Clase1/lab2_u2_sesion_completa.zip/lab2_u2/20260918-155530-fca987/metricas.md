| Métrica | Valor |
|---|---|
| experimento | interconexion_sistemas |
| topologia | paralelo |
| sistema1 | primer_orden |
| sistema2 | primer_orden |
| H1 | H(s) = [1] / [0.5·s + 1] |
| H2 | H(s) = [1] / [0.2·s + 1] |
| H_equivalente | H(s) = [0.7·s + 2] / [0.1·s^2 + 0.7·s + 1] |
| fs | 500.0 |
| duracion_observada | 5.0 |
| error_rms_relativo_prediccion | 1.1315238226965135e-15 |
| ganancia_dc_algebraica | 2.0 |
| valor_final_escalon_medido | 1.9999544180927964 |
| error_relativo_ganancia_dc | 2.2790953601803388e-05 |
| n_polos_equivalente | 2 |
| parte_real_maxima_polos | -2.000000000000001 |
| equivalente_estable | True |
| verificacion_h_equivalente | True |
| verificacion_ganancia_dc | True |
| Topología | paralelo |
| H₁ | H(s) = [1] / [0.5·s + 1] |
| H₂ | H(s) = [1] / [0.2·s + 1] |
| H equivalente | H(s) = [0.7·s + 2] / [0.1·s^2 + 0.7·s + 1] |
| Error RMS relativo vs predicción | 0.0 |
| Ganancia DC algebraica | 2.0 |
| Valor final medido del escalón | 1.999954 |
| Nº de polos del equivalente | 2 |
| Parte real máxima de los polos | -2.0 |
| ¿Equivalente BIBO estable? | True |
