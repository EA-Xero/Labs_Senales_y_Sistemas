| Métrica | Valor |
|---|---|
| experimento | interconexion_sistemas |
| topologia | realimentacion_negativa |
| sistema1 | inestable |
| sistema2 | primer_orden |
| H1 | H(s) = [1] / [0.5·s + -1] |
| H2 | H(s) = [5] / [0.2·s + 1] |
| H_equivalente | H(s) = [0.2·s + 1] / [0.1·s^2 + 0.3·s + 4] |
| fs | 500.0 |
| duracion_observada | 5.0 |
| error_rms_relativo_prediccion | 0.0 |
| ganancia_dc_algebraica | 0.25 |
| valor_final_escalon_medido | 0.2497992369231605 |
| error_relativo_ganancia_dc | 0.0008030523073579987 |
| n_polos_equivalente | 2 |
| parte_real_maxima_polos | -1.4999999999999996 |
| equivalente_estable | True |
| verificacion_h_equivalente | True |
| verificacion_ganancia_dc | True |
| Topología | realimentacion_negativa |
| H₁ | H(s) = [1] / [0.5·s + -1] |
| H₂ | H(s) = [5] / [0.2·s + 1] |
| H equivalente | H(s) = [0.2·s + 1] / [0.1·s^2 + 0.3·s + 4] |
| Error RMS relativo vs predicción | 0.0 |
| Ganancia DC algebraica | 0.25 |
| Valor final medido del escalón | 0.249799 |
| Nº de polos del equivalente | 2 |
| Parte real máxima de los polos | -1.5 |
| ¿Equivalente BIBO estable? | True |
