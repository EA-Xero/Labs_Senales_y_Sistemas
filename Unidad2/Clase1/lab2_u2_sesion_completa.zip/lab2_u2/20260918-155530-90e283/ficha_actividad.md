# Actividad guiada: A4 · Interconexión: serie, paralelo y realimentación
Laboratorio 2 · Unidad 2 · Clase 1 (Sistemas LTI y convolución)
#### A4 · Interconexión: serie, paralelo y realimentación  ·  20 min
*Experimento:* `interconexion_sistemas`

**Objetivo.** Comprobar h_eq = h₁*h₂ en cascada, h_eq = h₁+h₂ en paralelo y ver cómo la realimentación mueve los polos.

**Procedimiento**

1. Lanza la actividad: cubre las tres topologías con los mismos H₁ y H₂.
2. Para la cascada, compara h_eq simulada con la convolución h₁*h₂.
3. Para el lazo cerrado, anota los polos y compáralos con los de H₁.
4. Prueba la variante que realimenta un sistema inestable y observa el cambio de estabilidad.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| Error RMS relativo entre h_eq simulada y la predicción ≤ tolerancia | Figura h_eq vs predicción |
| Valor final del escalón = H_eq(0) | Tabla CSV |
| Los polos del lazo cerrado son raíces de d₁d₂ + n₁n₂ | Figura de polos en el plano s |

**Preguntas de análisis (van al informe)**

- ¿Por qué el orden de las etapas en cascada no cambia la salida?
- ¿Qué le pasó a la ganancia DC al cerrar el lazo y por qué?
