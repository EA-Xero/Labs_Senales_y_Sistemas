| Métrica | Valor |
|---|---|
| experimento | interconexion_sistemas |
| topologia | serie |
| sistema1 | primer_orden |
| sistema2 | primer_orden |
| H1 | H(s) = [1] / [0.5·s + 1] |
| H2 | H(s) = [1] / [0.2·s + 1] |
| H_equivalente | H(s) = [1] / [0.1·s^2 + 0.7·s + 1] |
| fs | 500.0 |
| duracion_observada | 5.0 |
| error_rms_relativo_prediccion | 0.0032951642413293924 |
| ganancia_dc_algebraica | 1.0 |
| valor_final_escalon_medido | 0.9999240301873984 |
| error_relativo_ganancia_dc | 7.596981260160618e-05 |
| n_polos_equivalente | 2 |
| parte_real_maxima_polos | -2.000000000000001 |
| equivalente_estable | True |
| verificacion_h_equivalente | True |
| verificacion_ganancia_dc | True |
| Topología | serie |
| H₁ | H(s) = [1] / [0.5·s + 1] |
| H₂ | H(s) = [1] / [0.2·s + 1] |
| H equivalente | H(s) = [1] / [0.1·s^2 + 0.7·s + 1] |
| Error RMS relativo vs predicción | 0.003295 |
| Ganancia DC algebraica | 1.0 |
| Valor final medido del escalón | 0.999924 |
| Nº de polos del equivalente | 2 |
| Parte real máxima de los polos | -2.0 |
| ¿Equivalente BIBO estable? | True |
