# Actividad guiada: A1 · Convolución paso a paso
Laboratorio 2 · Unidad 2 · Clase 1 (Sistemas LTI y convolución)
#### A1 · Convolución paso a paso  ·  15 min
*Experimento:* `convolucion_animada`

**Objetivo.** Ver los cuatro pasos (reflejar, desplazar, multiplicar, integrar) y comprobar que la duración de la salida es la suma de duraciones.

**Procedimiento**

1. Lanza la actividad y sigue en *Vista en vivo* el deslizamiento de h reflejada sobre x.
2. Anota cuándo empieza y cuándo termina el solape: ahí está el soporte.
3. Repite con la variante triangular–triangular y compara la forma resultante.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| T_y = T_x + T_h en la salida medida | Figura PNG/SVG de y(t) |
| La salida vale cero fuera del intervalo de solape | Tabla CSV de la corrida |

**Preguntas de análisis (van al informe)**

- ¿Por qué la convolución de dos pulsos rectangulares da un trapecio?
- ¿Qué duración de ventana necesitó y cómo la dimensionó?

**Errores frecuentes**

- Ventana demasiado corta: la salida aparece truncada antes de T_x+T_h.
