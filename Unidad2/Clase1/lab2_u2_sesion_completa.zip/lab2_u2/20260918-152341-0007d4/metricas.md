| Métrica | Valor |
|---|---|
| experimento | convolucion_animada |
| tipo_x | triangular |
| tipo_h | triangular |
| amplitud_x | 1.0 |
| amplitud_h | 1.0 |
| ancho_x | 1.0 |
| ancho_h | 0.6 |
| fs | 200.0 |
| n_muestras_x | 201 |
| n_muestras_h | 121 |
| n_muestras_y | 321 |
| area_x | 0.5 |
| area_h | 0.3 |
| area_y | 0.15 |
| area_y_teorica | 0.15 |
| error_relativo_area | 0.0 |
| error_conmutatividad | 0.0 |
| energia_x | 0.33335000000000004 |
| energia_h | 0.20002777777777778 |
| energia_y | 0.026036590507958333 |
| max_y | 0.24001666666666668 |
| t_max_y_s | 0.8 |
| duracion_y_s | 1.6 |
| duracion_y_teorica_s | 1.6 |
| t_instantanea_s | 0.81 |
| Entrada x(t) | triangular |
| Respuesta al impulso h(t) | triangular |
| ∫x dt | 0.5 |
| ∫h dt | 0.3 |
| ∫y dt (medida) | 0.15 |
| (∫x)·(∫h) (teórica) | 0.15 |
| Error relativo de área | 0.0 |
| Error de conmutatividad |x∗h − h∗x| | 0.0 |
| Máximo de y(t) | 0.240017 |
| Instante del máximo [s] | 0.8 |
| Duración del soporte de y [s] | 1.6 |
