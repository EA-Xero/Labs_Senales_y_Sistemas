| Métrica | Valor |
|---|---|
| experimento | convolucion_animada |
| tipo_x | doble_pulso |
| tipo_h | rectangular |
| amplitud_x | 1.0 |
| amplitud_h | 1.0 |
| ancho_x | 1.0 |
| ancho_h | 0.6 |
| fs | 200.0 |
| n_muestras_x | 201 |
| n_muestras_h | 121 |
| n_muestras_y | 321 |
| area_x | 0.5025000000000001 |
| area_h | 0.605 |
| area_y | 0.30401249999999996 |
| area_y_teorica | 0.3040125 |
| error_relativo_area | 1.8259496313887694e-16 |
| error_conmutatividad | 0.0 |
| energia_x | 0.41875 |
| energia_h | 0.605 |
| energia_y | 0.07248828125000001 |
| max_y | 0.335 |
| t_max_y_s | 0.33 |
| duracion_y_s | 1.6 |
| duracion_y_teorica_s | 1.6 |
| t_instantanea_s | 0.81 |
| Entrada x(t) | doble_pulso |
| Respuesta al impulso h(t) | rectangular |
| ∫x dt | 0.5025 |
| ∫h dt | 0.605 |
| ∫y dt (medida) | 0.304012 |
| (∫x)·(∫h) (teórica) | 0.304013 |
| Error relativo de área | 0.0 |
| Error de conmutatividad |x∗h − h∗x| | 0.0 |
| Máximo de y(t) | 0.335 |
| Instante del máximo [s] | 0.33 |
| Duración del soporte de y [s] | 1.6 |
