| Métrica | Valor |
|---|---|
| experimento | serie_fourier_gibbs |
| senal | cuadrada |
| amplitud | 1.0 |
| f0_hz | 2.0 |
| periodo_s | 0.5 |
| n_armonicos | 51 |
| fs | 4000.0 |
| potencia_en_el_tiempo | 1.0 |
| potencia_por_parseval | 0.992224364136023 |
| error_relativo_parseval | 0.007775635863977004 |
| fraccion_de_potencia_en_N_armonicos | 0.992224364136023 |
| error_simetria_conjugada | 0.0 |
| sobreimpulso_final_por_ciento | 8.956395321841626 |
| sobreimpulso_teorico_gibbs_por_ciento | 8.95 |
| error_relativo_gibbs | 0.0007145610996230851 |
| error_rms_final | 0.08817956602284432 |
| pendiente_loglog_coeficientes | -0.999725370414279 |
| error_max_coeficientes_vs_teoria | 1.336177245521257e-05 |
| verificacion_parseval | True |
| verificacion_simetria_conjugada | True |
| verificacion_gibbs | True |
| verificacion_decaimiento_1_sobre_k | True |
| Señal | cuadrada |
| f₀ [Hz] | 2.0 |
| Armónicos usados N | 51 |
| Potencia en el tiempo | 1.0 |
| Potencia por Parseval Σ|c_k|² | 0.992224 |
| Error relativo de Parseval | 0.007776 |
| Fracción de potencia en N armónicos | 0.992224 |
| Sobreimpulso medido [%] | 8.956 |
| Sobreimpulso teórico de Gibbs [%] | 8.95 |
| Pendiente log–log de |c_k| | -0.9997 |
| Error de simetría conjugada | 0.0 |
| Error máx |c_k| vs teoría (cuadrada) | 1.3e-05 |
