| Métrica | Valor |
|---|---|
| experimento | serie_fourier_gibbs |
| senal | cuadrada |
| amplitud | 1.0 |
| f0_hz | 2.0 |
| periodo_s | 0.5 |
| n_armonicos | 15 |
| fs | 4000.0 |
| potencia_en_el_tiempo | 1.0 |
| potencia_por_parseval | 0.974707841611961 |
| error_relativo_parseval | 0.025292158388039 |
| fraccion_de_potencia_en_N_armonicos | 0.974707841611961 |
| error_simetria_conjugada | 0.0 |
| sobreimpulso_final_por_ciento | 9.01528002897114 |
| sobreimpulso_teorico_gibbs_por_ciento | 8.95 |
| error_relativo_gibbs | 0.007293857985602402 |
| error_rms_final | 0.15903508539954092 |
| pendiente_loglog_coeficientes | -0.9999696209450691 |
| error_max_coeficientes_vs_teoria | 3.927245180529448e-06 |
| verificacion_parseval | True |
| verificacion_simetria_conjugada | True |
| verificacion_gibbs | True |
| verificacion_decaimiento_1_sobre_k | True |
| Señal | cuadrada |
| f₀ [Hz] | 2.0 |
| Armónicos usados N | 15 |
| Potencia en el tiempo | 1.0 |
| Potencia por Parseval Σ|c_k|² | 0.974708 |
| Error relativo de Parseval | 0.025292 |
| Fracción de potencia en N armónicos | 0.974708 |
| Sobreimpulso medido [%] | 9.015 |
| Sobreimpulso teórico de Gibbs [%] | 8.95 |
| Pendiente log–log de |c_k| | -1.0 |
| Error de simetría conjugada | 0.0 |
| Error máx |c_k| vs teoría (cuadrada) | 4e-06 |
