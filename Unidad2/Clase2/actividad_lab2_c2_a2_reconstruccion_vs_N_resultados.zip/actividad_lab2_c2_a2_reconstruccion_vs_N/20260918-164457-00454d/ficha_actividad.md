# Actividad guiada: A2 · ¿Cuántos armónicos hacen falta?
Laboratorio 2 · Unidad 2 · Clase 2 (Series de Fourier: espectro de líneas, Gibbs y Parseval)
#### A2 · ¿Cuántos armónicos hacen falta?  ·  15 min
*Experimento:* `serie_fourier_gibbs`

**Objetivo.** Cuantificar el compromiso entre número de armónicos, error RMS y potencia capturada, para justificar el N usado en el informe.

**Procedimiento**

1. Lanza las tres corridas con N creciente.
2. Tabula error RMS y fracción de potencia frente a N.
3. Elige y justifica el N que usará el grupo en el resto del laboratorio.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| El error RMS decrece monótonamente con N | Gráfico error RMS vs N |
| La fracción de potencia capturada crece y tiende a 1 | Gráfico de potencia acumulada |

**Preguntas de análisis (van al informe)**

- ¿Qué criterio usó para elegir N: error RMS o potencia capturada?
