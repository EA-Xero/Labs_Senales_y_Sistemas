| Métrica | Valor |
|---|---|
| experimento | serie_fourier_gibbs |
| senal | cuadrada |
| amplitud | 1.0 |
| f0_hz | 2.0 |
| periodo_s | 0.5 |
| n_armonicos | 5 |
| fs | 4000.0 |
| potencia_en_el_tiempo | 1.0 |
| potencia_por_parseval | 0.9330575222645098 |
| error_relativo_parseval | 0.06694247773549022 |
| fraccion_de_potencia_en_N_armonicos | 0.9330575222645098 |
| error_simetria_conjugada | 0.0 |
| sobreimpulso_final_por_ciento | 9.41795039435861 |
| sobreimpulso_teorico_gibbs_por_ciento | 8.95 |
| error_relativo_gibbs | 0.052284960263531834 |
| error_rms_final | 0.25873244430393805 |
| pendiente_loglog_coeficientes | -0.9999943669484729 |
| error_max_coeficientes_vs_teoria | 1.309006359334619e-06 |
| verificacion_parseval | False |
| verificacion_simetria_conjugada | True |
| verificacion_gibbs | True |
| verificacion_decaimiento_1_sobre_k | True |
| Señal | cuadrada |
| f₀ [Hz] | 2.0 |
| Armónicos usados N | 5 |
| Potencia en el tiempo | 1.0 |
| Potencia por Parseval Σ|c_k|² | 0.933058 |
| Error relativo de Parseval | 0.066942 |
| Fracción de potencia en N armónicos | 0.933058 |
| Sobreimpulso medido [%] | 9.418 |
| Sobreimpulso teórico de Gibbs [%] | 8.95 |
| Pendiente log–log de |c_k| | -1.0 |
| Error de simetría conjugada | 0.0 |
| Error máx |c_k| vs teoría (cuadrada) | 1e-06 |
