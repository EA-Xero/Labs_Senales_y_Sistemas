# Bundle de resultados — simulador CIT2410

Evidencia exportada por el simulador para el informe de laboratorio.
Todos los valores provienen de la simulación ejecutada (cálculo real);
no hay datos precomputados.

| Corrida | Experimento | Actividad | Gráficos (PNG+SVG) |
|---|---|---|---|
| `20260918-164258-ed5927` | serie_fourier_gibbs | A1 · Coeficientes, Gibbs, Parseval y decaimiento | 6 |
| `20260918-164258-a4afb7` | serie_fourier_gibbs | A1 · Coeficientes, Gibbs, Parseval y decaimiento | 6 |
| `20260918-164258-174704` | serie_fourier_gibbs | A1 · Coeficientes, Gibbs, Parseval y decaimiento | 6 |
| `20260918-164258-09def5` | serie_fourier_gibbs | A1 · Coeficientes, Gibbs, Parseval y decaimiento | 6 |
| `20260918-164258-0508bb` | serie_fourier_gibbs | A1 · Coeficientes, Gibbs, Parseval y decaimiento | 6 |

## Contenido por corrida

- `resultado.json` — resultado completo (métricas y series).
- `metricas.csv` / `metricas.md` — tabla de valores de interés.
- `series.csv` — todas las series numéricas alineadas por índice.
- `config.json` — parámetros exactos con los que se corrió.
- `ficha_actividad.md` — objetivo, pasos, verificaciones y preguntas.
- `graficos/*.png` y `graficos/*.svg` — todas las figuras en ambos formatos.
