| Métrica | Valor |
|---|---|
| experimento | serie_fourier_gibbs |
| senal | diente_sierra |
| amplitud | 1.0 |
| f0_hz | 2.0 |
| periodo_s | 0.5 |
| n_armonicos | 25 |
| fs | 4000.0 |
| potencia_en_el_tiempo | 0.3333335 |
| potencia_por_parseval | 0.3253920088292361 |
| error_relativo_parseval | 0.023824461600060978 |
| fraccion_de_potencia_en_N_armonicos | 0.976175538399939 |
| error_simetria_conjugada | 0.0 |
| sobreimpulso_final_por_ciento | 7.044862571779024 |
| sobreimpulso_teorico_gibbs_por_ciento | 8.95 |
| error_relativo_gibbs | 0.21286451711966203 |
| error_rms_final | 0.08911504458150708 |
| pendiente_loglog_coeficientes | -0.9999204421005374 |
| error_max_coeficientes_vs_teoria | 0.0 |
| verificacion_parseval | True |
| verificacion_simetria_conjugada | True |
| verificacion_gibbs | True |
| verificacion_decaimiento_1_sobre_k | True |
| Señal | diente_sierra |
| f₀ [Hz] | 2.0 |
| Armónicos usados N | 25 |
| Potencia en el tiempo | 0.333334 |
| Potencia por Parseval Σ|c_k|² | 0.325392 |
| Error relativo de Parseval | 0.023824 |
| Fracción de potencia en N armónicos | 0.976176 |
| Sobreimpulso medido [%] | 7.045 |
| Sobreimpulso teórico de Gibbs [%] | 8.95 |
| Pendiente log–log de |c_k| | -0.9999 |
| Error de simetría conjugada | 0.0 |
| Error máx |c_k| vs teoría (cuadrada) | 0.0 |
