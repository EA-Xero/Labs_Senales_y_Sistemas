| Métrica | Valor |
|---|---|
| experimento | serie_fourier_gibbs |
| senal | triangular |
| amplitud | 1.0 |
| f0_hz | 2.0 |
| periodo_s | 0.5 |
| n_armonicos | 25 |
| fs | 4000.0 |
| potencia_en_el_tiempo | 0.333334 |
| potencia_por_parseval | 0.33333088363702434 |
| error_relativo_parseval | 9.349070228883782e-06 |
| fraccion_de_potencia_en_N_armonicos | 0.9999906509297711 |
| error_simetria_conjugada | 0.0 |
| sobreimpulso_final_por_ciento | -0.7785768146686578 |
| sobreimpulso_teorico_gibbs_por_ciento | 8.95 |
| error_relativo_gibbs | 1.0869918228680064 |
| error_rms_final | 0.0017653223432744657 |
| pendiente_loglog_coeficientes | -1.9998519795981475 |
| error_max_coeficientes_vs_teoria | 0.0 |
| verificacion_parseval | True |
| verificacion_simetria_conjugada | True |
| verificacion_gibbs | False |
| verificacion_decaimiento_1_sobre_k | True |
| Señal | triangular |
| f₀ [Hz] | 2.0 |
| Armónicos usados N | 25 |
| Potencia en el tiempo | 0.333334 |
| Potencia por Parseval Σ|c_k|² | 0.333331 |
| Error relativo de Parseval | 9e-06 |
| Fracción de potencia en N armónicos | 0.999991 |
| Sobreimpulso medido [%] | -0.779 |
| Sobreimpulso teórico de Gibbs [%] | 8.95 |
| Pendiente log–log de |c_k| | -1.9999 |
| Error de simetría conjugada | 0.0 |
| Error máx |c_k| vs teoría (cuadrada) | 0.0 |
