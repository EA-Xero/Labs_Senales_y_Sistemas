# Actividad guiada: A1 · Coeficientes, Gibbs, Parseval y decaimiento
Laboratorio 2 · Unidad 2 · Clase 2 (Series de Fourier: espectro de líneas, Gibbs y Parseval)
#### A1 · Coeficientes, Gibbs, Parseval y decaimiento  ·  25 min
*Experimento:* `serie_fourier_gibbs`

**Objetivo.** Obtener las cinco verificaciones de la sesión sobre una onda cuadrada y contrastarlas con otras formas de onda.

**Procedimiento**

1. Lanza la corrida principal (cuadrada, N = 25) y observa la reconstrucción creciendo armónico a armónico.
2. Compara |c_k| medido con 2A/(πk) para k impar y confirma los ceros en k par.
3. Mira el gráfico de sobreimpulso vs N: debe acercarse al 8,95 % sin bajar.
4. Revisa el balance de potencia: qué fracción queda dentro de N armónicos.
5. Repite con triangular y diente de sierra y compara las pendientes log–log.

**Verificaciones esperadas**

| Criterio numérico | Evidencia a exportar |
|---|---|
| |c_k| = 2A/(πk) en k impar y ≈ 0 en k par (onda cuadrada) | Tabla CSV de coeficientes + espectro de líneas |
| Sobreimpulso → 8,95 % al crecer N | Gráfico sobreimpulso vs N |
| Potencia en el tiempo = Σ|c_k|² (error ≤ tolerancia) | Tabla CSV de balance de potencia |
| c₋ₖ = c*ₖ (error ≈ 0) | Tabla CSV de simetría |
| Pendiente ≈ −1 en log–log de |c_k| (cuadrada) | Gráfico log–log de |c_k| |

**Preguntas de análisis (van al informe)**

- ¿Por qué el sobreimpulso no desaparece al aumentar N?
- ¿Qué diferencia hay entre la pendiente log–log de la cuadrada y la de la triangular, y qué dice sobre la suavidad de la señal?
- ¿Cuántos armónicos necesita para capturar el 99 % de la potencia?

**Errores frecuentes**

- Observar menos de un periodo completo: los coeficientes salen mal.
- Confundir el sobreimpulso de Gibbs con un error del simulador.
