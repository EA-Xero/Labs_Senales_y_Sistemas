| Métrica | Valor |
|---|---|
| experimento | serie_fourier_gibbs |
| senal | cuadrada |
| amplitud | 1.0 |
| f0_hz | 2.0 |
| periodo_s | 0.5 |
| n_armonicos | 75 |
| fs | 4000.0 |
| potencia_en_el_tiempo | 1.0 |
| potencia_por_parseval | 0.9946929712310598 |
| error_relativo_parseval | 0.005307028768940181 |
| fraccion_de_potencia_en_N_armonicos | 0.9946929712310598 |
| error_simetria_conjugada | 0.0 |
| sobreimpulso_final_por_ciento | 8.941462308991987 |
| sobreimpulso_teorico_gibbs_por_ciento | 8.95 |
| error_relativo_gibbs | 0.0009539319562024761 |
| error_rms_final | 0.07284935668171962 |
| pendiente_loglog_coeficientes | -0.9994290880753935 |
| error_max_coeficientes_vs_teoria | 1.9666794224632023e-05 |
| verificacion_parseval | True |
| verificacion_simetria_conjugada | True |
| verificacion_gibbs | True |
| verificacion_decaimiento_1_sobre_k | True |
| Señal | cuadrada |
| f₀ [Hz] | 2.0 |
| Armónicos usados N | 75 |
| Potencia en el tiempo | 1.0 |
| Potencia por Parseval Σ|c_k|² | 0.994693 |
| Error relativo de Parseval | 0.005307 |
| Fracción de potencia en N armónicos | 0.994693 |
| Sobreimpulso medido [%] | 8.941 |
| Sobreimpulso teórico de Gibbs [%] | 8.95 |
| Pendiente log–log de |c_k| | -0.9994 |
| Error de simetría conjugada | 0.0 |
| Error máx |c_k| vs teoría (cuadrada) | 2e-05 |
