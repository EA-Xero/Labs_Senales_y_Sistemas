| Métrica | Valor |
|---|---|
| experimento | serie_fourier_gibbs |
| senal | tren_pulsos |
| amplitud | 1.0 |
| f0_hz | 2.0 |
| periodo_s | 0.5 |
| n_armonicos | 25 |
| fs | 4000.0 |
| potencia_en_el_tiempo | 0.2 |
| potencia_por_parseval | 0.19595744285048783 |
| error_relativo_parseval | 0.020212785747560913 |
| fraccion_de_potencia_en_N_armonicos | 0.9797872142524391 |
| error_simetria_conjugada | 0.0 |
| sobreimpulso_final_por_ciento | 9.930332959993503 |
| sobreimpulso_teorico_gibbs_por_ciento | 8.95 |
| error_relativo_gibbs | 0.10953440893782168 |
| error_rms_final | 0.0636367535732879 |
| pendiente_loglog_coeficientes | -0.9923166490609029 |
| error_max_coeficientes_vs_teoria | 0.0 |
| verificacion_parseval | True |
| verificacion_simetria_conjugada | True |
| verificacion_gibbs | True |
| verificacion_decaimiento_1_sobre_k | True |
| Señal | tren_pulsos |
| f₀ [Hz] | 2.0 |
| Armónicos usados N | 25 |
| Potencia en el tiempo | 0.2 |
| Potencia por Parseval Σ|c_k|² | 0.195957 |
| Error relativo de Parseval | 0.020213 |
| Fracción de potencia en N armónicos | 0.979787 |
| Sobreimpulso medido [%] | 9.93 |
| Sobreimpulso teórico de Gibbs [%] | 8.95 |
| Pendiente log–log de |c_k| | -0.9923 |
| Error de simetría conjugada | 0.0 |
| Error máx |c_k| vs teoría (cuadrada) | 0.0 |
