| Métrica | Valor |
|---|---|
| experimento | serie_fourier_gibbs |
| senal | cuadrada |
| amplitud | 1.0 |
| f0_hz | 2.0 |
| periodo_s | 0.5 |
| n_armonicos | 25 |
| fs | 4000.0 |
| potencia_en_el_tiempo | 1.0 |
| potencia_por_parseval | 0.984428463706628 |
| error_relativo_parseval | 0.015571536293372046 |
| fraccion_de_potencia_en_N_armonicos | 0.984428463706628 |
| error_simetria_conjugada | 0.0 |
| sobreimpulso_final_por_ciento | 8.976426568527529 |
| sobreimpulso_teorico_gibbs_por_ciento | 8.95 |
| error_relativo_gibbs | 0.0029526892209530485 |
| error_rms_final | 0.12478596192429797 |
| pendiente_loglog_coeficientes | -0.9999259897990624 |
| error_max_coeficientes_vs_teoria | 6.546162425256907e-06 |
| verificacion_parseval | True |
| verificacion_simetria_conjugada | True |
| verificacion_gibbs | True |
| verificacion_decaimiento_1_sobre_k | True |
| Señal | cuadrada |
| f₀ [Hz] | 2.0 |
| Armónicos usados N | 25 |
| Potencia en el tiempo | 1.0 |
| Potencia por Parseval Σ|c_k|² | 0.984428 |
| Error relativo de Parseval | 0.015572 |
| Fracción de potencia en N armónicos | 0.984428 |
| Sobreimpulso medido [%] | 8.976 |
| Sobreimpulso teórico de Gibbs [%] | 8.95 |
| Pendiente log–log de |c_k| | -0.9999 |
| Error de simetría conjugada | 0.0 |
| Error máx |c_k| vs teoría (cuadrada) | 7e-06 |
